package com.Assignment.Day22;

import com.Assignment.Day22.DAO.UserDao;
import com.Assignment.Day22.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@SpringBootApplication
public class Day22Application  implements CommandLineRunner {

	@Autowired
	private UserDao userDao;

	public static void main(String[] args) {
		SpringApplication.run(Day22Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		//User user = new User("Ram","Ram@gmail.com");
		//userDao.addUser(user);

		//User user = userDao.getUserById(3);
		//System.out.println(user.toString());

		//userDao.updateUserEmail(3,"rakesh1@gmail.com");
		//userDao.deleteUser(3);

//		List<User> users = new ArrayList<>();
//		users.add(new User(7,"Raju1@gmail.com"));
//		users.add(new User(8,"Raj1@gmail.com"));
//		users.add(new User(9,"Rahul1@gmail.com"));
//		users.add(new User(10,"Amit1@gmail.com"));

		//userDao.AddUsers(users);
        //userDao.updateUsersEmails(users);

//		String Domain = "%@gmail.com";
//        List<User> users = userDao.getUsersByEmailDomain(Domain);
//		for(User u : users)
//		{
//			System.out.println(u.toString());
//		}

		List<User> users = userDao.getAllUsers();
		for(User u : users)
		{
			System.out.println(u.toString());
		}

		//System.out.println(userDao.getUserCount());
//		User user = new User("Ram","Ram@gmail.com");
//		userDao.addUserWithExceptionalHandling(user);
	}
}
