package com.Assignment.Day22.DAO;

import com.Assignment.Day22.Exception.DuplicateKeyException;
import com.Assignment.Day22.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void addUser(User user)
    {
        try
        {
            String SqlAddUser = "insert into users(name, email) values (?,?)";
            int cnt = jdbcTemplate.update(SqlAddUser,user.getName(),user.getEmail());
            if(cnt>0)
            {
                System.out.println("Insertion of a new record");
            }
            else {
                System.out.println("new record not inserted");
            }

        }catch(Exception e)
        {
            System.out.println("new record not inserted due to some error");
            e.printStackTrace();
        }
    }

    public User getUserById(int id)
    {
        String SqlUserByID = "select * from users where id = ?";
        return jdbcTemplate.queryForObject(SqlUserByID, (rs , rownum) -> new User(rs.getInt(1),rs.getString(2),rs.getString(3)),id);
    }

    public void updateUserEmail(int id, String email)
    {
        String SqlUpdateUser = "update users set email = ? where id = ? ";
       int cnt = jdbcTemplate.update(SqlUpdateUser,email,id);
        if(cnt>0)
        {
            System.out.println("updation of a new record");
        }
        else {
            System.out.println(" record not updated");
        }

    }

    public void deleteUser(int id)
    {
        String SqlDeleteUser = "delete from users where id = ? ";
        int cnt = jdbcTemplate.update(SqlDeleteUser,id);
        if(cnt>0)
        {
            System.out.println("Deletion of a record");
        }
        else {
            System.out.println(" record not deleted");
        }
    }

    public void AddUsers(List<User> users)
    {
        String query = "Insert into users (name , email) values (?,?) ";
        jdbcTemplate.batchUpdate(query,users, users.size(), (ps, user) -> {
            ps.setString(1,user.getName());
            ps.setString(2,user.getEmail());
        }
        );
    }

    public void updateUsersEmails(List<User> users)
    {
        String query = "update users set email = ? where id = ?";
        jdbcTemplate.batchUpdate(query,users, users.size(), (ps, user) -> {
                    ps.setString(1,user.getEmail());
                    ps.setInt(2, user.getId());
                }
        );
    }

    public List<User> getAllUsers()
    {
        String selectQuery ="Select * from users";
       return  jdbcTemplate.query(selectQuery, (rs , rownum) -> new User(rs.getInt(1),rs.getString(2), rs.getString(3))) ;
    }

    public List<User> getUsersByEmailDomain(String domain)
    {
        String query = "select * from users where email Like ?";
        return  jdbcTemplate.query(query, (rs , rownum) -> new User(rs.getInt(1),rs.getString(2), rs.getString(3)),domain) ;

    }

    public int getUserCount()
    {
        String Query = "select count(*) from users";
        int cnt = jdbcTemplate.queryForObject(Query,Integer.class);
        return cnt;
    }

    public void addUserWithExceptionalHandling(User user)
    {
        try
        {
            String SqlAddUser = "insert into users(name, email) values (?,?)";
            jdbcTemplate.update(SqlAddUser,user.getName(),user.getEmail());
            System.out.println("Insertion of a new record");

        }catch (DuplicateKeyException e)
        {
            throw new DuplicateKeyException("row already present "+user.getEmail() );
        }
        catch(Exception e)
        {
            System.out.println("new record not inserted due to some error");
            e.printStackTrace();
        }
    }
}
