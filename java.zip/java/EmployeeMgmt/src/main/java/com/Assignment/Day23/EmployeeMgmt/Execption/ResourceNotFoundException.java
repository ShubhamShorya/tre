package com.Assignment.Day23.EmployeeMgmt.Execption;

public class ResourceNotFoundException extends RuntimeException{
  public  ResourceNotFoundException(String message)
    {
        super(message);
    }
}
