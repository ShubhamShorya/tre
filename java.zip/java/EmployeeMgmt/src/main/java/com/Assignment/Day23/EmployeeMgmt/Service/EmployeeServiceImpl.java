package com.Assignment.Day23.EmployeeMgmt.Service;

import com.Assignment.Day23.EmployeeMgmt.DTO.EmployeeDTO;
import com.Assignment.Day23.EmployeeMgmt.Entity.Employee;
import com.Assignment.Day23.EmployeeMgmt.Execption.ResourceNotFoundException;
import com.Assignment.Day23.EmployeeMgmt.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository employeeRepository;

    private EmployeeDTO mapToDTO(Employee saveEmployee) {
        return new EmployeeDTO(saveEmployee);
    }
    @Override
    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO)
    {
        Employee savedEmployee = new Employee(employeeDTO);
        employeeRepository.save(savedEmployee);
        return mapToDTO(savedEmployee);
    }



    @Override
    public List<EmployeeDTO> getAllEmployees() {
       List<EmployeeDTO> employeeList = employeeRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
       return employeeList;
    }

    @Override
    public Employee getEmployeeById(Long employeeId) {
        return employeeRepository.findById(employeeId).orElseThrow(() -> new ResourceNotFoundException("Resource not Exists."));

    }

    @Override
    public EmployeeDTO updateEmployee(EmployeeDTO employeeDTO, Long employeeID) {
        Employee existingEmployee = employeeRepository.findById(employeeID).orElseThrow(() -> new ResourceNotFoundException("Resource not Exists."));

            existingEmployee.setFirstName(employeeDTO.getFirstName());
            existingEmployee.setLastName(employeeDTO.getLastName());
            existingEmployee.setDepartment(employeeDTO.getDepartment());
            existingEmployee.setEmail(employeeDTO.getEmail());
            employeeRepository.save(existingEmployee);
            return mapToDTO(existingEmployee);

    }

    @Override
    public void deleteEmployee(Long employeeId) {
        employeeRepository.deleteById(employeeId);
    }


}
