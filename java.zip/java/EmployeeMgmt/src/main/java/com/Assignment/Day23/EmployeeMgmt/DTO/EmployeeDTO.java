package com.Assignment.Day23.EmployeeMgmt.DTO;

import com.Assignment.Day23.EmployeeMgmt.Entity.Employee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.Pattern;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {

    private Long id;
    private String firstName;
    private String lastName;
    @Pattern(regexp = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$", message = "invalid email")
    private String email;
    private String department;
    private Double salary;

    public EmployeeDTO(Employee employee)
    {
        this.id=employee.getId();
        this.firstName=employee.getFirstName();
        this.lastName= employee.getLastName();
        this.email= employee.getEmail();
        this.department=employee.getDepartment();
        this.salary=employee.getSalary();
    }
}
