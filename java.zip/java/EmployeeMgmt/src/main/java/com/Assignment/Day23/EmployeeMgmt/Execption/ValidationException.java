package com.Assignment.Day23.EmployeeMgmt.Execption;

public class ValidationException extends RuntimeException{

   public ValidationException(String msg)
    {
        super(msg);
    }
}
