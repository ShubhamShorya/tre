package com.Assignment.Day23.EmployeeMgmt.Entity;

import com.Assignment.Day23.EmployeeMgmt.DTO.EmployeeDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employee")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String department;
    private Double salary;

    public Employee(EmployeeDTO employeeDTO)
    {
        this.id=employeeDTO.getId();
        this.firstName=employeeDTO.getFirstName();
        this.lastName= employeeDTO.getLastName();
        this.email= employeeDTO.getEmail();
        this.department=employeeDTO.getDepartment();
        this.salary=employeeDTO.getSalary();
    }
}
