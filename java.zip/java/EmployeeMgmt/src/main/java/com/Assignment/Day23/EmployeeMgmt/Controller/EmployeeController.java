package com.Assignment.Day23.EmployeeMgmt.Controller;

import com.Assignment.Day23.EmployeeMgmt.DTO.EmployeeDTO;
import com.Assignment.Day23.EmployeeMgmt.Entity.Employee;
import com.Assignment.Day23.EmployeeMgmt.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @RequestMapping(value ="/POST" , method = RequestMethod.POST)
    public String createEmployee(@Valid @RequestBody EmployeeDTO employeeDTO)
    {
        employeeService.createEmployee(employeeDTO);
        return "employee is created";
    }

    @RequestMapping(value = "/GET/{id}" , method = RequestMethod.GET)
    public Employee getEmployeeById(@PathVariable Long id)
    {
         return employeeService.getEmployeeById(id);
    }

    @RequestMapping(value = "/GET" , method = RequestMethod.GET)
    public List<EmployeeDTO> getAllEmployees()
    {
        return employeeService.getAllEmployees();
    }

    @RequestMapping(value ="/PUT/{id}" , method = RequestMethod.PUT)
    public String updateEmployee(@RequestBody EmployeeDTO employeeDTO , @PathVariable Long id)
    {
        EmployeeDTO employeeDTO1 = employeeService.updateEmployee(employeeDTO,id);
        return "employee with id " + id + " is updated";
    }

    @RequestMapping(value ="/DELETE/{id}" , method = RequestMethod.DELETE)
    public String updateEmployee(@PathVariable Long id)
    {
        employeeService.deleteEmployee(id);
        return "employee with id " + id + " is deleted";
    }

}
