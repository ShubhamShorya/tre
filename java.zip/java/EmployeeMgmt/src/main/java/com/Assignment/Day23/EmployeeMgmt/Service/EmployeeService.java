package com.Assignment.Day23.EmployeeMgmt.Service;

import com.Assignment.Day23.EmployeeMgmt.DTO.EmployeeDTO;
import com.Assignment.Day23.EmployeeMgmt.Entity.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {

    EmployeeDTO createEmployee(EmployeeDTO employeeDTO);

    List<EmployeeDTO> getAllEmployees();

    Employee getEmployeeById(Long employeeId);

    EmployeeDTO updateEmployee(EmployeeDTO employeeDTO ,Long employeeID);

    void deleteEmployee(Long employeeId);
}
