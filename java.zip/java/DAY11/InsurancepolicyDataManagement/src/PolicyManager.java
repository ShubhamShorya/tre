import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyManager implements FileHandler {
    @Override
    public List<Policy> readPolicies(String fileName) throws IOException {
        List<Policy> policies = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                int policyId = Integer.parseInt(data[0]);
                String policyHolderName = data[1];
                double policyAmount = Double.parseDouble(data[2]);
                policies.add(new Policy(policyId, policyHolderName, policyAmount));
            }
        }
        return policies;
    }

    @Override
    public void writeSummary(String fileName, int totalPolicies, double totalAmount) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write("Total Number of Policies: " + totalPolicies);
            bw.newLine();
            bw.write("Total Policy Amount: " + totalAmount);
        }
    }

    public static void main(String[] args) {
        PolicyManager policyManager = new PolicyManager();
        try {
            List<Policy> policies = policyManager.readPolicies("C:\\Users\\Yuvraj.Kaushal\\IdeaProjects\\DAY11\\InsurancepolicyDataManagement\\policies.txt");
            int totalPolicies = policies.size();
            double totalAmount = policies.stream().mapToDouble(Policy::getPolicyAmount).sum();
            policyManager.writeSummary("summary.txt", totalPolicies, totalAmount);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}