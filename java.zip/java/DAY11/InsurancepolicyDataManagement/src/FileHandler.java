import java.io.IOException;
import java.util.List;

public interface FileHandler {
    List<Policy> readPolicies(String filePath) throws IOException;
    void writeSummary(String filePath, int totalPolicies, double totalAmount) throws IOException;
}
