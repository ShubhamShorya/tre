import java.io.IOException;
import java.util.List;

public class Policy {
    private int policyID;
    private String policyHolderName;
    private double policyAmount;

    public Policy(int policyID, String policyHolderName, double policyAmount) {
        this.policyID = policyID;
        this.policyHolderName = policyHolderName;
        this.policyAmount = policyAmount;
    }

    public int getPolicyID() {
        return policyID;
    }

    public String getPolicyHolderName() {
        return policyHolderName;
    }

    public double getPolicyAmount() {
        return policyAmount;
    }
}
