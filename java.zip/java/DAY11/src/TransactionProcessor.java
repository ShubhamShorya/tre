import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TransactionProcessor {
    public static void main(String[] args) {
        String inputFilePath = "transactions.txt";
        String outputFilePath = "filtered_transactions.txt";
        double thresholdAmount = 1000.0; // Set your desired threshold amount here

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into transaction details
                String[] fields = line.split(",");
                if (fields.length >= 3) {
                    double transactionAmount = Double.parseDouble(fields[2]);
                    if (transactionAmount > thresholdAmount) {
                        // Write the filtered transaction to the output file
                        writer.write(line);
                        writer.newLine(); // Add a newline after each record
                    }
                }
            }
            System.out.println("Filtered transactions written to " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error reading/writing the file: " + e.getMessage());
        }
    }
}
