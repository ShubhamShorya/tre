import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class WriteUserInputToFile {
    public static void main(String[] args) {
        String filePath = "destination.txt";

        try (Scanner scanner = new Scanner(System.in);
             FileWriter writer = new FileWriter(filePath)) {

            System.out.print("Enter your input: ");
            String userInput = scanner.nextLine();

            writer.write(userInput);
            System.out.println("User input written to " + filePath);
        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
        }
    }
}
