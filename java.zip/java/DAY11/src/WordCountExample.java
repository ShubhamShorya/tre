import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class WordCountExample {
    public static void main(String[] args) {
        String filePath = "source.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            int wordCount = 0;

            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into words using whitespace as delimiter
                String[] words = line.split("\\s+");
                wordCount += words.length;
            }

            System.out.println("Total number of words in " + filePath + ": " + wordCount);
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }
}
