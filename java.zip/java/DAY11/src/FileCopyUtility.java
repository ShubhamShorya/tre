import java.io.*;

public class FileCopyUtility {
    public static void main(String[] args) {
        String sourceFile = "source.txt";
        String destinationFile = "destination.txt";

        try {
            // Open the source file for reading
            BufferedReader reader = new BufferedReader(new FileReader(sourceFile));

            // Open the destination file for writing
            BufferedWriter writer = new BufferedWriter(new FileWriter(destinationFile));

            String line;
            while ((line = reader.readLine()) != null) {
                // Read a line from the source file
                // Write the same line to the destination file
                writer.write(line);
                writer.newLine(); // Add a newline character
            }

            // Close the files
            reader.close();
            writer.close();

            System.out.println("Contents of " + sourceFile + " successfully copied to " + destinationFile);
        } catch (FileNotFoundException e) {
            System.err.println("Error: " + sourceFile + " not found.");
        } catch (IOException e) {
            System.err.println("Error while reading/writing files: " + e.getMessage());
        }
    }
}