import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseFileContent {
    public static void main(String[] args) {
        String inputFilePath = "source.txt";
        String reversedFilePath = "reversed.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(reversedFilePath))) {

            StringBuilder reversedContent = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                // Reverse the line and append to the StringBuilder
                reversedContent.append(new StringBuilder(line).reverse()).append("\n");
            }

            // Write the reversed content to reversed.txt
            writer.write(reversedContent.toString());
            System.out.println("Content reversed and written to " + reversedFilePath);
        } catch (IOException e) {
            System.err.println("Error reading/writing the file: " + e.getMessage());
        }
    }
}
