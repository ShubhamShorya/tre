
import java.util.concurrent.Semaphore;

public class DiningPhilosophers {

    private static final int NUM_PHILOSOPHERS = 5;
    private static final Semaphore[] chopsticks = new Semaphore[NUM_PHILOSOPHERS];

    public static void main(String[] args) {
        for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
            chopsticks[i] = new Semaphore(1);
        }

        for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
            final int philosopher = i;
            new Thread(() -> {
                try {
                    while (true) {
                        think(philosopher);
                        pickUpChopsticks(philosopher);
                        eat(philosopher);
                        putDownChopsticks(philosopher);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        }
    }

    private static void think(int philosopher) throws InterruptedException {
        System.out.println("Philosopher " + philosopher + " is thinking.");
        Thread.sleep((int) (Math.random() * 100));
    }

    private static void pickUpChopsticks(int philosopher) throws InterruptedException {
        int leftChopstick = philosopher;
        int rightChopstick = (philosopher + 1) % NUM_PHILOSOPHERS;

        if (philosopher % 2 == 0) {
            chopsticks[leftChopstick].acquire();
            chopsticks[rightChopstick].acquire();
        } else {
            chopsticks[rightChopstick].acquire();
            chopsticks[leftChopstick].acquire();
        }

        System.out.println("Philosopher " + philosopher + " picked up chopsticks.");
    }

    private static void eat(int philosopher) throws InterruptedException {
        System.out.println("Philosopher " + philosopher + " is eating.");
        Thread.sleep((int) (Math.random() * 100));
    }

    private static void putDownChopsticks(int philosopher) {
        int leftChopstick = philosopher;
        int rightChopstick = (philosopher + 1) % NUM_PHILOSOPHERS;

        chopsticks[leftChopstick].release();
        chopsticks[rightChopstick].release();

        System.out.println("Philosopher " + philosopher + " put down chopsticks.");
    }
}
