import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class ProducerConsumer {

    private static final int BUFFER_SIZE = 5;
    private static final Queue<Integer> buffer = new LinkedList<>();
    private static final Semaphore mutex = new Semaphore(1);
    private static final Semaphore items = new Semaphore(0);
    private static final Semaphore spaces = new Semaphore(BUFFER_SIZE);

    public static void main(String[] args) {
        Thread producer = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                try {
                    spaces.acquire();
                    mutex.acquire();
                    buffer.add(i);
                    System.out.println("Produced: " + i);
                    mutex.release();
                    items.release();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });

        Thread consumer = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                try {
                    items.acquire();
                    mutex.acquire();
                    int item = buffer.poll();
                    System.out.println("Consumed: " + item);
                    mutex.release();
                    spaces.release();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });

        producer.start();
        consumer.start();
    }
}