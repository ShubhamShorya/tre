import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MatrixMultiplication {

    private static final int THREAD_POOL_SIZE = 4;

    public static void main(String[] args) {
        int[][] matrixA = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        int[][] matrixB = {
                {9, 8, 7},
                {6, 5, 4},
                {3, 2, 1}
        };

        int[][] result = new int[matrixA.length][matrixB[0].length];
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

        for (int i = 0; i < matrixA.length; i++) {
            for (int j = 0; j < matrixB[0].length; j++) {
                final int row = i;
                final int col = j;
                executor.execute(() -> {
                    for (int k = 0; k < matrixA[0].length; k++) {
                        synchronized (result) {
                            result[row][col] += matrixA[row][k] * matrixB[k][col];
                        }
                    }
                });
            }
        }

        executor.shutdown();
        while (!executor.isTerminated()) {}

        // Print the result matrix
        for (int[] row : result) {
            for (int val : row) {
                System.out.print(val + " ");
            }
            System.out.println();
        }
    }
}