import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LivelockExample {

    private static final Lock lock1 = new ReentrantLock();
    private static final Lock lock2 = new ReentrantLock();

    public static void main(String[] args) {
        Thread thread1 = new Thread(() -> {
            while (true) {
                if (lock1.tryLock()) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                    }
                    if (lock2.tryLock()) {
                        try {
                            System.out.println("Thread 1: Acquired both locks!");
                            break;
                        } finally {
                            lock2.unlock();
                        }
                    }
                    lock1.unlock();
                }
            }
        });

        Thread thread2 = new Thread(() -> {
            while (true) {
                if (lock2.tryLock()) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                    }
                    if (lock1.tryLock()) {
                        try {
                            System.out.println("Thread 2: Acquired both locks!");
                            break;
                        } finally {
                            lock1.unlock();
                        }
                    }
                    lock2.unlock();
                }
            }
        });

        thread1.start();
        thread2.start();
    }
}