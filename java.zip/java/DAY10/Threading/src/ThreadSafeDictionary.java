
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class ThreadSafeDictionary {
    private final Map<String, String> map = new ConcurrentHashMap<>();

    public String get(String key) {
        return map.get(key);
    }

    public void put(String key, String value) {
        map.put(key, value);
    }

    public void remove(String key) {
        map.remove(key);
    }

    public static void main(String[] args) {
        ThreadSafeDictionary dictionary = new ThreadSafeDictionary();

        // Example usage of the dictionary in multiple threads
        Thread writer = new Thread(() -> {
            dictionary.put("key1", "value1");
            dictionary.put("key2", "value2");
            System.out.println("Inserted values.");
        });

        Thread reader = new Thread(() -> {
            System.out.println("key1: " + dictionary.get("key1"));
            System.out.println("key2: " + dictionary.get("key2"));
        });

        writer.start();
        reader.start();
    }
}

