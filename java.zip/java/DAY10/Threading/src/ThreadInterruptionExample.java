
public class ThreadInterruptionExample {
    public static void main(String[] args) {
        Thread thread = new Thread(new LongRunningTask());
        thread.start();

        try {
            Thread.sleep(3000);  // Allow the thread to run for a while
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        thread.interrupt();  // Interrupt the thread
    }
}

class LongRunningTask implements Runnable {
    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            System.out.println("Running...");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println("Thread was interrupted and is stopping.");
    }
}
