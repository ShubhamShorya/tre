import java.util.*;
import java.io.*;

public class EmployeeManagementSystem {
    private static List<Employee> employees = new ArrayList<>();
    private static final String FILE_NAME = "employees.json";

    public static void main(String[] args) {
        loadEmployees();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Add a New Employee");
            System.out.println("2. View All Employees");
            System.out.println("3. Update Employee Details");
            System.out.println("4. Delete an Employee");
            System.out.println("5. Search for an Employee");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addEmployee(scanner);
                    break;
                case 2:
                    viewAllEmployees();
                    break;
                case 3:
                    updateEmployee(scanner);
                    break;
                case 4:
                    deleteEmployee(scanner);
                    break;
                case 5:
                    searchEmployee(scanner);
                    break;
                case 6:
                    saveEmployees();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee(Scanner scanner) {
        System.out.print("Enter Employee ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Department: ");
        String department = scanner.nextLine();

        System.out.print("Enter Street: ");
        String street = scanner.nextLine();

        System.out.print("Enter City: ");
        String city = scanner.nextLine();

        System.out.print("Enter Zipcode: ");
        String zipcode = scanner.nextLine();

        Address address = new Address(street, city, zipcode);

        List<Project> projects = new ArrayList<>();
        System.out.print("Enter number of projects: ");
        int numProjects = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < numProjects; i++) {
            System.out.print("Enter Project ID: ");
            int projectId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter Project Name: ");
            String projectName = scanner.nextLine();

            System.out.print("Enter Project Status: ");
            String status = scanner.nextLine();

            projects.add(new Project(projectId, projectName, status));
        }

        employees.add(new Employee(id, name, department, address, projects));
        System.out.println("Employee added successfully!");
    }

    private static void viewAllEmployees() {
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    private static void updateEmployee(Scanner scanner) {
        System.out.print("Enter Employee ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (Employee employee : employees) {
            if (employee.employeeId == id) {
                System.out.print("Enter new Name: ");
                employee.name = scanner.nextLine();

                System.out.print("Enter new Department: ");
                employee.department = scanner.nextLine();

                System.out.print("Enter new Street: ");
                employee.address.street = scanner.nextLine();

                System.out.print("Enter new City: ");
                employee.address.city = scanner.nextLine();

                System.out.print("Enter new Zipcode: ");
                employee.address.zipcode = scanner.nextLine();

                System.out.print("Enter number of projects: ");
                int numProjects = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                employee.projects.clear();
                for (int i = 0; i < numProjects; i++) {
                    System.out.print("Enter Project ID: ");
                    int projectId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter Project Name: ");
                    String projectName = scanner.nextLine();

                    System.out.print("Enter Project Status: ");
                    String status = scanner.nextLine();

                    employee.projects.add(new Project(projectId, projectName, status));
                }

                System.out.println("Employee updated successfully!");
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    private static void deleteEmployee(Scanner scanner) {
        System.out.print("Enter Employee ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        employees.removeIf(employee -> employee.employeeId == id);
        System.out.println("Employee deleted successfully!");
    }

    private static void searchEmployee(Scanner scanner) {
        System.out.print("Enter Employee ID to search: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (Employee employee : employees) {
            if (employee.employeeId == id) {
                System.out.println(employee);
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    private static void loadEmployees() {
        // Load employees from JSON file (implementation not shown)
    }

    private static void saveEmployees() {
        // Save employees to JSON file (implementation not shown)
    }
}

