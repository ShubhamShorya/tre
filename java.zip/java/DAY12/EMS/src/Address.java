import java.util.List;

class Address {
    String street;
    String city;
    String zipcode;

    public Address(String street, String city, String zipcode) {
        this.street = street;
        this.city = city;
        this.zipcode = zipcode;
    }

    @Override
    public String toString() {
        return street + ", " + city + ", " + zipcode;
    }
}

class Project {
    int projectId;
    String projectName;
    String status;

    public Project(int projectId, String projectName, String status) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Project ID: " + projectId + ", Name: " + projectName + ", Status: " + status;
    }
}

class Employee {
    int employeeId;
    String name;
    String department;
    Address address;
    List<Project> projects;

    public Employee(int employeeId, String name, String department, Address address, List<Project> projects) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        this.address = address;
        this.projects = projects;
    }

    @Override
    public String toString() {
        return "ID: " + employeeId + ", Name: " + name + ", Department: " + department + ", Address: " + address + ", Projects: " + projects;
    }
}

