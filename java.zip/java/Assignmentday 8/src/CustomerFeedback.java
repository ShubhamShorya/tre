import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;


class FeedbackNotFoundException extends Exception {
    public FeedbackNotFoundException(String message) {
        super(message);
    }
}

class InvalidFeedbackContentException extends RuntimeException {
    public InvalidFeedbackContentException(String message) {
        super(message);
    }
}

class Feedback {
    private int id;
    private String customerName;
    private String content;

    public Feedback(int id, String customerName, String content) {
        this.id = id;
        this.customerName = customerName;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "Feedback{id=" + id + ", customerName='" + customerName + "', content='" + content + "'}";
    }
}

public class CustomerFeedback{
    private Map<Integer, Feedback> feedbacks = new HashMap<>();
    private int feedbackCounter = 1;
    private static final Pattern INAPPROPRIATE_CONTENT_PATTERN = Pattern.compile("(bad|terrible|awful)", Pattern.CASE_INSENSITIVE);

    public void submitFeedback(String customerName, String content) {
        if (customerName == null || customerName.isEmpty() || content == null || content.isEmpty()) {
            throw new InvalidFeedbackContentException("Customer name and content cannot be null or empty.");
        }
        if (INAPPROPRIATE_CONTENT_PATTERN.matcher(content).find()) {
            throw new InvalidFeedbackContentException("Feedback content contains inappropriate words.");
        }
        int id = feedbackCounter++;
        feedbacks.put(id, new Feedback(id, customerName, content));
        log("Feedback submitted: " + id);
    }

    public Feedback getFeedback(int id) throws FeedbackNotFoundException {
        if (!feedbacks.containsKey(id)) {
            throw new FeedbackNotFoundException("Feedback with the given ID not found.");
        }
        return feedbacks.get(id);
    }

    private void log(String message) {
        System.out.println("LOG: " + message);
    }

    public static void main(String[] args) {
        CustomerFeedback cfs = new CustomerFeedback();
        try {
            cfs.submitFeedback("Alice", "Great service!");
            cfs.submitFeedback("Bob", "Terrible experience."); // This will throw InvalidFeedbackContentException
            Feedback feedback = cfs.getFeedback(1);
            System.out.println("Retrieved feedback: " + feedback);
            cfs.getFeedback(2);  // This will throw FeedbackNotFoundException
        } catch (FeedbackNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (InvalidFeedbackContentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
