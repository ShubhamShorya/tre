import java.time.LocalDate;
class FraudulentClaimException extends RuntimeException {
    public FraudulentClaimException(String message) {
        super(message);
    }
}

class InvalidClaimAmountException extends RuntimeException {
    public InvalidClaimAmountException(String message) {
        super(message);
    }
}
public class ClaimProcessing2{
    private double maxClaimAmount = 10000.0;
    private LocalDate policyStartDate = LocalDate.of(2023, 1, 1); // Policy start date
    private LocalDate policyEndDate = LocalDate.of(2024, 1, 1); // Policy end date

    public void processClaim(double claimAmount, LocalDate claimDate) {
        if (claimAmount > maxClaimAmount) {
            throw new InvalidClaimAmountException("Claim amount exceeds the maximum allowed amount.");
        }
        if (claimDate.isBefore(policyStartDate) || claimDate.isAfter(policyEndDate)) {
            throw new FraudulentClaimException("Claim date is outside the policy coverage period.");
        }

        System.out.println("Claim processed successfully.");
    }

    public static void main(String[] args) {
        ClaimProcessing2 system = new ClaimProcessing2();

        try {

            system.processClaim(5000.0, LocalDate.of(2023, 6, 15));


            system.processClaim(15000.0, LocalDate.of(2023, 6, 15));


            system.processClaim(5000.0, LocalDate.of(2025, 6, 15));
        } catch (InvalidClaimAmountException | FraudulentClaimException e) {
            System.err.println("Claim processing failed: " + e.getMessage());
            System.out.println("Notification sent to the claims department for further investigation.");
        }
    }
}
