class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

public class Throwing_Exception{
    private double balance;

    public Throwing_Exception(double initialBalance) {
        this.balance = initialBalance;
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException("Error: Insufficient funds. Your balance is " + balance);
        }
        balance -= amount;
        System.out.println("Withdrawal successful. Remaining balance: " + balance);
    }

    public static void main(String[] args) {
        Throwing_Exception account = new Throwing_Exception(500.00);

        try {
            account.withdraw(600.00);
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage());
        }
    }
}