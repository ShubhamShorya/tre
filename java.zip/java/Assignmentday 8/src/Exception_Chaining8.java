import java.io.FileReader;
import java.io.IOException;


class CustomException extends Exception {
    public CustomException(String message, Throwable cause) {
        super(message, cause);
    }
}

public class Exception_Chaining8{
    public static void main(String[] args) {
        try {

            readFile();
        } catch (CustomException e) {

            System.out.println("Caught CustomException: " + e.getMessage());
            System.out.println("Cause of the CustomException: " + e.getCause());
            System.out.println("Original IOException message: " + e.getCause().getMessage());
        }
    }


    private static void readFile() throws CustomException {
        try {

            FileReader fileReader = new FileReader("non_existent_file.txt");
        } catch (IOException e) {

            throw new CustomException("Failed to read file", e);
        }
    }
}


