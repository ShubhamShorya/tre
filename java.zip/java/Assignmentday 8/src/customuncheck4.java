import java.util.Scanner;

class NegativeNumberException extends RuntimeException {
    public NegativeNumberException(String message) {
        super(message);
    }
}

public class customuncheck4{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();

        try {
            checkNumber(number);
            System.out.println("The number is valid.");
        } catch (NegativeNumberException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void checkNumber(int number) {
        if (number < 0) {
            throw new NegativeNumberException("Error: Negative numbers are not allowed.");
        }
    }
}
