import java.util.HashMap;
import java.util.Map;


class CustomerNotFoundException extends Exception {
    public CustomerNotFoundException(String message) {
        super(message);
    }
}
class InvalidCustomerDataException extends RuntimeException {
    public InvalidCustomerDataException(String message) {
        super(message);
    }
}
class Customer {
    private int id;
    private String name;
    private String email;

    public Customer(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Customer{id=" + id + ", name='" + name + "', email='" + email + "'}";
    }
}


public class CustomerManagement5{
    private Map<Integer, Customer> customers = new HashMap<>();

    // Method to add a customer
    public void addCustomer(int id, String name, String email) {
        if (name == null || name.isEmpty() || email == null || email.isEmpty()) {
            throw new InvalidCustomerDataException("Customer name and email cannot be null or empty.");
        }
        if (customers.containsKey(id)) {
            throw new InvalidCustomerDataException("Customer with the given ID already exists.");
        }
        customers.put(id, new Customer(id, name, email));
        log("Customer added: " + id);
    }

    public void updateCustomer(int id, String name, String email) throws CustomerNotFoundException {
        if (name == null || name.isEmpty() || email == null || email.isEmpty()) {
            throw new InvalidCustomerDataException("Customer name and email cannot be null or empty.");
        }
        if (!customers.containsKey(id)) {
            throw new CustomerNotFoundException("Customer with the given ID not found.");
        }
        Customer customer = customers.get(id);
        customer.setName(name);
        customer.setEmail(email);
        log("Customer updated: " + id);
    }

    public void deleteCustomer(int id) throws CustomerNotFoundException {
        if (!customers.containsKey(id)) {
            throw new CustomerNotFoundException("Customer with the given ID not found.");
        }
        customers.remove(id);
        log("Customer deleted: " + id);
    }

    private void log(String message) {
        System.out.println("LOG: " + message);
    }

    public static void main(String[] args) {
        CustomerManagement5 cms = new CustomerManagement5();
        try {
            cms.addCustomer(1, "John Doe", "john@example.com");
            cms.updateCustomer(1, "John D.", "john.d@example.com");
            cms.deleteCustomer(1);
            cms.deleteCustomer(1);  // This will throw CustomerNotFoundException
        } catch (CustomerNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (InvalidCustomerDataException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
 