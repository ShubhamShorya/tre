class PolicyApplication1 extends Exception {
    public PolicyApplication1(String message) {
        super(message);
    }
}

class PoorDrivingRecordException extends Exception {
    public PoorDrivingRecordException(String message) {
        super(message);
    }
}

class HealthIssueException extends Exception {
    public HealthIssueException(String message) {
        super(message);
    }
}


class PolicyApplication {
    private int age;
    private boolean hasPoorDrivingRecord;
    private boolean hasHealthIssues;

    public PolicyApplication(int age, boolean hasPoorDrivingRecord, boolean hasHealthIssues) {
        this.age = age;
        this.hasPoorDrivingRecord = hasPoorDrivingRecord;
        this.hasHealthIssues = hasHealthIssues;
    }

    public void validate() throws InvalidAgeException, PoorDrivingRecordException, HealthIssueException {
        if (age < 18 || age > 65) {
            throw new InvalidAgeException("Age must be between 18 and 65.");
        }
        if (hasPoorDrivingRecord) {
            throw new PoorDrivingRecordException("Driving record is not acceptable.");
        }
        if (hasHealthIssues) {
            throw new HealthIssueException("Health issues detected.");
        }
    }

    public static void main(String[] args) {
        try {
            PolicyApplication application = new PolicyApplication(20, false, false);
            application.validate();
            System.out.println("Policy application is valid.");
        } catch (InvalidAgeException | PoorDrivingRecordException | HealthIssueException e) {
            System.err.println("Validation failed: " + e.getMessage());
        }
    }
}