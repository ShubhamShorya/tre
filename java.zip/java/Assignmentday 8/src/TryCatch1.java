import java.util.Scanner;

public class TryCatch1{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int input = scanner.nextInt();

        try {
            int result = 100 / input;
            System.out.println("100 divided by " + input + " is " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        }
    }
}