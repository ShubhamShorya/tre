public class Exception_Hierarchy5{
    public static void main(String[] args) {
        try {

            int result = 10 / 0;
            String str = null;
            str.length();

        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException: Division by zero is not allowed.");
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: Attempted to use an object reference that is null.");
        } catch (Exception e) {
            System.out.println("Generic Exception: An unexpected error occurred.");
        } finally {
            System.out.println("Exception handling is complete.");
        }
    }
}