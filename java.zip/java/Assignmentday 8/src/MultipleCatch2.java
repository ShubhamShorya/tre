import java.util.*;
public class MultipleCatch2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        try{
            int value1= sc.nextInt();
            int value2= sc.nextInt();
            int result = value1/value2;
            System.out.println("100 divided by " + value1 + " is " + result);

        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        }catch (InputMismatchException e) {
            System.out.println("please enter valid integer");
        }
        }
    }

