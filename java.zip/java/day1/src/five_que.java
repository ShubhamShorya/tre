// Leap Year
//a. I/P -> Year, ensure it is a 4-digit number.
//b. Logic -> Determine if it is a Leap Year.
//c. O/P -> Print the year as a Leap Year or not
import java.util.*;
public class five_que {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the year");
        int year= sc.nextInt();
        if(year> 0 && year<10000){
            if (year % 4 == 0 || year % 100 == 0 || year % 400 == 0) {
                System.out.println(year + "it is a Leap year");
            } else {
                System.out.println(year + "Is not a leap year");
            }
        }
        else {
            System.out.println("Please enter 4-digit number");
        }

    }

}
