////2. Student Management System:
////● Create a class Student with the following fields: studentId, name, age, and
////grade.
////● Include methods to set and get the values of these fields.
////● Write a method to display the details of the student.
////● In the Main class, create multiple Student objects, set their details, and display
////them
public class student {
   private int studentId;
    private int age;
    private  String name;
    private   String grade;
   public student(int studentId,String name,int age,String grade) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }
        void setValue ( int studentId, String name,int age, String grade){
            this.studentId = studentId;
            this.name = name;
            this.age = age;
            this.grade = grade;

        }


     int getStudentId(){
        return this.studentId;
    }
    String getName(){
        return this.name;
    }
    int getAge(){
        return this.age;
    }
    String getGrade(){
        return grade;
    }
    void display(){
        System.out.println(studentId+" "+ name +" "+ age+" " +grade);


    }

    public static void main(String[] args) {
        student obj=new student(01, "shubham", 23,"A");
        student obj1=new student(03, "shorya", 24,"A+");
        student obj3=new student(05, "Raj", 20, "B");
        obj.display();
        obj1.display();
        obj3.display();



    }




}
