import java.util.Scanner;
public class rectangle {
    public static void area(double l,double b){
        double area=0;
        area=l*b;
        System.out.println("Area of the given rectangle is " + area );
    }
    public static void perimeter(double l,double b){
        double perimeter=0;
        perimeter=2*(l+b);
        System.out.println("perimeter of the given rectangle is "+ perimeter);
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter the length of the rectangle");
        double length = sc.nextDouble();
        System.out.println("Please enter the breath of the rectangle");
        double breath=sc.nextDouble();
        rectangle obj=new rectangle();
        obj.area(length,breath);
        obj.perimeter(length,breath);


    }



}
