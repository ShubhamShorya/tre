//Write a Java program to display the default value of all primitive data types
import java.util.Scanner;
public class Default_value {
    static int a1;
    static boolean a2;
    static double a3;
    static float a4;
    static long a5;
    static String a6;
    static char a7;
    public static void main(String[] args) {
        System.out.println("Default values are.....");
        System.out.println("int =" + a1);
        System.out.println("boolean =" + a2);
        System.out.println("double =" + a3);
        System.out.println("float =" + a4);
        System.out.println("long =" + a5);
        System.out.println("String =" + a6);
        System.out.println("char =" + a7);




    }
}
