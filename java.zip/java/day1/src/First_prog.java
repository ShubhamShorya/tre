//Write a program to display any messge

import java.util.*;
public class First_prog {
    public static void main(String[] args) {
        System.out.println("Hello"+" "+ "My First program");
    }

}
