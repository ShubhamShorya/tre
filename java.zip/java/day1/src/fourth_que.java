//Flip Coin and print percentage of Heads and Tails
//a. I/P -> The number of times to Flip Coin. Ensure it is a positive integer.
//b. Logic -> Use a Random Function to get a value between 0 and 1. If < 0.5 then tails or
//Heads
//c. O/P -> Percentage of Head vs Tails

import java.util.Scanner;
import java.util.Random;
public class fourth_que {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of time you want to flip the coin");
        Random random=new Random();
        double heads=0;
        double tails=0;
        double times=0;
       // double d=0.5;
        double percentage=0;
        int a = sc.nextInt();
        if (a >0) {
            for (int i = 0; i<a;i++ ){
                times= random.nextDouble();
                if(times < 0.5){
                    tails++;
                }
                else {
                    heads++;
                }
            }
            percentage = (heads/tails)*100;
            System.out.println("percentage is "+ percentage);
            //percentage=(tails*100)/a;
           // System.out.println("tail percenatge is "+percentage);
        }
        else{
            System.out.println("Please enter a positive number");
        }
    }
}
