//Q3.Write a program to check if two Strings are equal or not.
import java.util.Scanner;
public class third_que {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter First word");
        String a = sc.nextLine();
        System.out.println("Enter second word");
        String b = sc.nextLine();
        System.out.println(a.equals(b));




    }
}
