// Power of 2
//a. Desc -> This program takes a command-line argument N and prints a table of the
//powers of 2 that are less than or equal to 2^N.
//b. I/P -> The Power Value N. Only works if 0 <= N < 31 since 2^31 overflows an int
//c. Logic -> repeat until i equals N.
//d. O/P -> Print the year as a Leap Year or not

import java.util.Scanner;
public class sixth_que {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double mult=1;
        System.out.println("Enter the number between 0 to 31");
        int num=sc.nextInt();
       for (int i=0;i<=num;i++){
            mult=Math.pow(2,i);
           System.out.println(mult);
        }


    }
}
