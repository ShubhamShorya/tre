package com.godigit.springexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
