package Assignment_Day_16;



import java.util.Scanner;

public class Abstract {
    // Abstract product interfaces
    interface Button {
        void render();
    }

    interface TextField {
        void render();
    }

    // Concrete product classes for Light Theme
    static class LightButton implements Button {
        @Override
        public void render() {
            System.out.println("Rendering Light Button");
        }
    }

    static class LightTextField implements TextField {
        @Override
        public void render() {
            System.out.println("Rendering Light Text Field");
        }
    }

    // Concrete product classes for Dark Theme
    static class DarkButton implements Button {
        @Override
        public void render() {
            System.out.println("Rendering Dark Button");
        }
    }

    static class DarkTextField implements TextField {
        @Override
        public void render() {
            System.out.println("Rendering Dark Text Field");
        }
    }

    // Factory method to create UI components based on theme
    public static UIFactory getFactory(String theme) {
        if (theme == null) {
            return null;
        }
        if (theme.equalsIgnoreCase("LIGHT")) {
            return new LightThemeFactory();
        } else if (theme.equalsIgnoreCase("DARK")) {
            return new DarkThemeFactory();
        }
        return null;
    }

    // Abstract factory interface
    interface UIFactory {
        Button createButton();
        TextField createTextField();
    }

    // Concrete factory classes for each theme
    static class LightThemeFactory implements UIFactory {
        @Override
        public Button createButton() {
            return new LightButton();
        }

        @Override
        public TextField createTextField() {
            return new LightTextField();
        }
    }

    static class DarkThemeFactory implements UIFactory {
        @Override
        public Button createButton() {
            return new DarkButton();
        }

        @Override
        public TextField createTextField() {
            return new DarkTextField();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter theme (LIGHT or DARK): ");
        String theme = scanner.nextLine();

        UIFactory factory = getFactory(theme);
        if (factory != null) {
            Button button = factory.createButton();
            TextField textField = factory.createTextField();
            button.render();
            textField.render();
        } else {
            System.out.println("Invalid theme selected.");
        }

        scanner.close();
    }
}
