package Assignment_Day_16;

public class Singleton {
    // Static variable to hold the single instance of the class
    private static Singleton instance;

    // Private constructor to prevent instantiation from other classes
    private Singleton() {
        // Initialize configuration settings here
    }

    // Public method to provide access to the instance
    public static Singleton getInstance() {
        if (instance == null) {
            synchronized (Singleton.class) {
                if (instance == null) {
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }

    // Example method to demonstrate functionality
    public void showConfiguration() {
        System.out.println("Configuration settings are displayed here.");
    }

    public static void main(String[] args) {
        // Access the Singleton instance and call its method
        Singleton singleton = Singleton.getInstance();
        singleton.showConfiguration();
    }
}
