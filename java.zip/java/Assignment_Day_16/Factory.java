package Assignment_Day_16;

public class Factory {
    // Shape interface
    interface Shape {
        void draw();
    }

    // Circle class implementing Shape interface
    static class Circle implements Shape {
        @Override
        public void draw() {
            System.out.println("Drawing a Circle");
        }
    }

    // Square class implementing Shape interface
    static class Square implements Shape {
        @Override
        public void draw() {
            System.out.println("Drawing a Square");
        }
    }

    // Factory method to create shapes based on input
    public Shape getShape(String shapeType) {
        if (shapeType == null) {
            return null;
        }
        if (shapeType.equalsIgnoreCase("CIRCLE")) {
            return new Circle();
        } else if (shapeType.equalsIgnoreCase("SQUARE")) {
            return new Square();
        }
        return null;
    }

    public static void main(String[] args) {
        Factory factory = new Factory();

        // Get an object of Circle and call its draw method
        Shape shape1 = factory.getShape("CIRCLE");
        shape1.draw();

        // Get an object of Square and call its draw method
        Shape shape2 = factory.getShape("SQUARE");
        shape2.draw();
    }
}
