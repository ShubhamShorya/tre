package Assignment_Day_16;



import java.util.Queue;
import java.util.LinkedList;

class DatabaseConnection {
    private String connectionString;

    public DatabaseConnection(String connectionString) {
        this.connectionString = connectionString;
        // Simulate opening a connection
        System.out.println("Opening connection to " + connectionString);
    }

    public void close() {
        // Simulate closing a connection
        System.out.println("Closing connection to " + connectionString);
    }

    public String getConnectionString() {
        return connectionString;
    }
}


public class ObjectPool {
    private Queue<DatabaseConnection> availableConnections;
    private int maxSize;

    public ObjectPool(int maxSize) {
        this.maxSize = maxSize;
        this.availableConnections = new LinkedList<>();
    }

    public synchronized DatabaseConnection borrowConnection(String connectionString) {
        if (availableConnections.isEmpty()) {
            if (availableConnections.size() < maxSize) {
                return new DatabaseConnection(connectionString);
            } else {
                throw new RuntimeException("No available connections");
            }
        } else {
            return availableConnections.poll();
        }
    }

    public synchronized void returnConnection(DatabaseConnection connection) {
        if (availableConnections.size() < maxSize) {
            availableConnections.offer(connection);
        } else {
            connection.close();
        }
    }
}

class Object {
    public static void main(String[] args) {
        ObjectPool pool = new ObjectPool(3);

        DatabaseConnection conn1 = pool.borrowConnection("db1");
        DatabaseConnection conn2 = pool.borrowConnection("db2");
        DatabaseConnection conn3 = pool.borrowConnection("db3");

        pool.returnConnection(conn1);
        pool.returnConnection(conn2);

        DatabaseConnection conn4 = pool.borrowConnection("db4");
        DatabaseConnection conn5 = pool.borrowConnection("db5");

        pool.returnConnection(conn3);
        pool.returnConnection(conn4);
        pool.returnConnection(conn5);
    }
}
