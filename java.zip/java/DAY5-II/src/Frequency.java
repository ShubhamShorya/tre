import java.util.HashMap;
import java.util.Map;

//Write a program that reads a string and counts the frequency of
//each character using a HashMap.
public class Frequency {
    public static void main(String[] args) {
        String str="yuvraj";
        char[] ch=str.toCharArray();
        int n=ch.length;
        Map<Character , Integer>map=new HashMap<>();
        for(int i=0 ; i<n ; i++){
            if(!map.containsKey(ch[i])){
                map.put(ch[i] , 1);
            }else{
               map.put(ch[i],map.get(ch[i])+1);
            }
        }
        System.out.println(map.entrySet());
    }

}
