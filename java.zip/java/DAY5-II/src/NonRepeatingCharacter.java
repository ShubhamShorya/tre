//Find the first non-repeated character in a string using a
//LinkedHashMap.

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class NonRepeatingCharacter {
    public static void main(String[] args) {
        String str="";
        Map<Character , Integer>mp=new LinkedHashMap<>();
        char[] ch=str.toCharArray();

        for(int i=0 ; i<ch.length ; i++){
            if(!mp.containsKey(ch[i])){
                mp.put(ch[i], 1);
            }else{
                mp.put(ch[i], mp.get(ch[i])+1);
            }
        }
        for(Map.Entry<Character, Integer> data:mp.entrySet()){
            if(mp.isEmpty()){
                System.out.println("enter element");
            }
            if(data.getValue()<2){
                System.out.println(data);
                return;
            }else{
                System.out.println("all are repeating");
            }
        }

    }
}
