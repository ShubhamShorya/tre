//Given an array of integers, find the duplicates and their
//counts using a HashMap.

import java.util.LinkedHashMap;
import java.util.Map;

public class DuplicateElementsinArray {
    public static void main(String[] args) {
        String str="yuvraaj";
        Map<Character , Integer>mp=new LinkedHashMap<>();
        char[] ch=str.toCharArray();

        for(int i=0 ; i<ch.length ; i++){
            if(!mp.containsKey(ch[i])){
                mp.put(ch[i], 1);
            }else{
                mp.put(ch[i], mp.get(ch[i])+1);
            }
        }
        for(Map.Entry<Character, Integer> data:mp.entrySet()){
            if(data.getValue()>1){
                System.out.println(data);
                return;
            }
        }

    }
}
