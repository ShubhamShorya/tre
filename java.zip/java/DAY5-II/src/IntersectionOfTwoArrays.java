import java.util.*;

public class IntersectionOfTwoArrays {
    public static int[] intersection(int[] x, int[] y) {
        Set<Integer> setX = new HashSet<>();
        Set<Integer> result = new HashSet<>();

        for (int num : x) {
            setX.add(num);
        }

        for (int num : y) {
            if (setX.contains(num)) {
                result.add(num);
            }
        }

        int[] intersectionArray = new int[result.size()];
        int index = 0;
        for (int num : result) {
            intersectionArray[index++] = num;
        }

        return intersectionArray;
    }

    public static void main(String[] args) {
        int[] array1 = {1, 3, 5, 7, 9};
        int[] array2 = {9, 3, 9, 4};

        int[] intersectionResult = intersection(array1, array2);

        System.out.println(Arrays.toString(intersectionResult));
    }
}