import java.time.LocalDate;
import java.util.*;

public class PolicyManagementSystem {
        private Map<String, Policy> policyMap = new HashMap<>();
        private Map<String, Policy> policyLinkedMap = new LinkedHashMap<>();
        private Map<LocalDate, Policy> policyTreeMap = new TreeMap<>();

        // Method to add a policy
        public void addPolicy(Policy policy) {
            policyMap.put(policy.getPolicyNumber(), policy);
            policyLinkedMap.put(policy.getPolicyNumber(), policy);
            policyTreeMap.put(policy.getExpiryDate(), policy);
        }

        // Method to retrieve a policy by its number
        public Policy getPolicyByNumber(String policyNumber) {
            return policyMap.get(policyNumber);
        }

        // Method to list all policies expiring within the next 30 days
        public List<Policy> getPoliciesExpiringSoon() {
            List<Policy> expiringPolicies = new ArrayList<>();
            LocalDate today = LocalDate.now();
            LocalDate next30Days = today.plusDays(30);

            for (Map.Entry<LocalDate, Policy> entry : policyTreeMap.entrySet()) {
                if (entry.getKey().isAfter(today) && entry.getKey().isBefore(next30Days)) {
                    expiringPolicies.add(entry.getValue());
                }
            }
            return expiringPolicies;
        }

        // Method to list all policies for a specific policyholder
        public List<Policy> getPoliciesByPolicyholder(String policyholderName) {
            List<Policy> policies = new ArrayList<>();
            for (Policy policy : policyMap.values()) {
                if (policy.getPolicyholderName().equals(policyholderName)) {
                    policies.add(policy);
                }
            }
            return policies;
        }

        // Method to remove expired policies
        public void removeExpiredPolicies() {
            LocalDate today = LocalDate.now();
            Iterator<Map.Entry<LocalDate, Policy>> iterator = policyTreeMap.entrySet().iterator();

            while (iterator.hasNext()) {
                Map.Entry<LocalDate, Policy> entry = iterator.next();
                if (entry.getKey().isBefore(today)) {
                    policyMap.remove(entry.getValue().getPolicyNumber());
                    policyLinkedMap.remove(entry.getValue().getPolicyNumber());
                    iterator.remove();
                }
            }
        }

        public static void main(String[] args) {
            PolicyManagementSystem system = new PolicyManagementSystem();

            // Adding some policies
            system.addPolicy(new Policy("P001", "John Doe", LocalDate.of(2024, 8, 15)));
            system.addPolicy(new Policy("P002", "Jane Smith", LocalDate.of(2024, 9, 10)));
            system.addPolicy(new Policy("P003", "Alice Johnson", LocalDate.of(2024, 7, 25)));

            // Retrieve a policy by its number
            System.out.println("Policy P001: " + system.getPolicyByNumber("P001"));

            // List all policies expiring within the next 30 days
            System.out.println("Policies expiring within the next 30 days: " + system.getPoliciesExpiringSoon());

            // List all policies for a specific policyholder
            System.out.println("Policies for John Doe: " + system.getPoliciesByPolicyholder("John Doe"));

            // Remove expired policies
            system.removeExpiredPolicies();
            System.out.println("Policies after removing expired ones: " + system.policyMap.values());
        }
    }


