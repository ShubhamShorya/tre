import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Given an array of strings, group anagrams together using a
//HashMap.
public class Anagram {
    public static void main(String[] args) {
        String[] arr = {"silent", "listen", "yuvraj", "gum", "mug"};
        Map<String, Integer> mp = new HashMap<>();
        Map<String, List<String>> m2=new HashMap<>();
        for (String value : arr) {
            String str = value;
            char[] ch = str.toCharArray();
            Arrays.sort(ch);


            String str2=new String(ch);
            if(!mp.containsKey(str2)){
                mp.put(str2, 1);
            }else {
                mp.put(str2, mp.get(str2)+1);
            }
        }
        System.out.println(mp.entrySet());
        }
    }

