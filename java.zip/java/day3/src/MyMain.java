import java.util.Scanner;

public class MyMain {
    public static void main(String[] args) {
        AddressBook addressBook = new AddressBook();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWhat do you want to do?");
            System.out.println("1. Add contact");
            System.out.println("2. Update contact");
            System.out.println("3. Delete contact");
            System.out.println("4. View contacts");
            System.out.println("5. Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    // Add contact
                    System.out.println("Enter first name: ");
                    String firstName = scanner.next();
                    System.out.println("Enter last name: ");
                    String lastName = scanner.next();
                    System.out.println("Enter address: ");
                    String address = scanner.next();
                    System.out.println("Enter city: ");
                    String city = scanner.next();
                    System.out.println("Enter zip code: ");
                    String zipCode = scanner.next();
                    System.out.println("Enter phone number: ");
                    String phoneNumber = scanner.next();
                    System.out.println("Enter email: ");
                    String email = scanner.next();

                    Contact newContact = new Contact();
                    newContact.setContactDetails(firstName, lastName, address, city, zipCode, phoneNumber, email);
                    addressBook.addContact(newContact);
                    System.out.println("Contact added successfully!");
                    break;

                case 2:
                    // Update contact
                    System.out.println("Enter first name of the contact to update: ");
                    String updateFirstName = scanner.next();
                    System.out.println("Enter last name of the contact to update: ");
                    String updateLastName = scanner.next();
                     addressBook.updateContact(updateFirstName,updateLastName);
                    System.out.println("Contact updated successfully!");
                    break;

                case 3:
                    // Delete contact
                    System.out.println("Enter first name of the contact to delete: ");
                    String deleteFirstName = scanner.next();
                    System.out.println("Enter last name of the contact to delete: ");
                    String deleteLastName = scanner.next();
                    addressBook.deleteContact(deleteFirstName, deleteLastName);
                    System.out.println("Contact deleted successfully!");
                    break;

                case 4:
                    // View contacts
                    addressBook.viewContacts();
                    break;

                case 5:
                    System.out.println("Exiting the address book. Goodbye!");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}
