import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
class AddressBook {
    private List<Contact> contacts;

    public AddressBook() {
        contacts = new ArrayList<>();
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }
    public void updateContact(String firstName, String lastName) {
        for (Contact contact : contacts) {
            if (contact.getFirstName().equals(firstName) && contact.getLastName().equals(lastName)) {
                // Prompt user for updates
                Scanner scanner = new Scanner(System.in);
                System.out.println("Which field would you like to update? (first_name, last_name, address, city, zip_code, phone_number, email)");
                String fieldToUpdate = scanner.nextLine();

                // Update the specified field based on user input
                switch (fieldToUpdate) {
                    case "first_name":
                        System.out.print("Enter new first name: ");
                        contact.setFirstName(scanner.nextLine());
                        break;
                    case "last_name":
                        System.out.print("Enter new last name: ");
                        contact.setLastName(scanner.nextLine());
                        break;
                    case "address":
                        System.out.print("Enter new address: ");
                        contact.setAddress(scanner.nextLine());
                        break;
                    case "city":
                        System.out.print("Enter new city: ");
                        contact.setCity(scanner.nextLine());
                        break;
                    case "zip_code":
                        System.out.print("Enter new zip code: ");
                        contact.setZipCode(scanner.nextLine());
                        break;
                    case "phone_number":
                        System.out.print("Enter new phone number: ");
                        contact.setPhoneNumber(scanner.nextLine());
                        break;
                    case "email":
                        System.out.print("Enter new email: ");
                        contact.setEmail(scanner.nextLine());
                        break;
                    default:
                        System.out.println("Invalid field: " + fieldToUpdate);
                        return;
                }

                System.out.println("Contact updated successfully!");
                return;
            }
        }
        System.out.println("Contact not found. Please check the first name and last name.");
    }


    public void deleteContact(String firstName, String lastName) {
        // Similar to Python implementation
        for (Contact contact : contacts) {
            if (contact.getFirstName().equals(firstName) && contact.getLastName().equals(lastName)) {
                contacts.remove(contact); // Remove the matching contact
                System.out.println("Contact deleted successfully!");
                return; // Exit the loop once the contact is removed
            }
        }
        System.out.println("Contact not found. Please check the first name and last name.");
    }

    public void viewContacts() {
        for (Contact contact : contacts) {
            contact.printContactDetails();
        }
    }
}
