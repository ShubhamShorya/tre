//Implement bubble sort


public class Bubble_sort {
     static void Bubble_sort(int[]arr){
         for(int i=0;i<arr.length;i++){
             System.out.print(arr[i]+ " ");
         }
         System.out.println();
     }


    public static void main(String[] args) {
        int[]arr={11,34,54,23,7};
         for(int i=0;i<arr.length;i++){
             for(int j=1;j<arr.length-i;j++){
                 if(arr[j-1]>arr[j]) {
                     int temp = arr[j];
                     arr[j] = arr[j-1];
                     arr[j-1] = temp;

                 }
             }
         }
        Bubble_sort(arr);
    }
}
