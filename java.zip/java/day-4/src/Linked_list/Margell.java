public class Margell {
    public static class Node{
        int data;
        Node next;
        Node(int data){
            this.data=data;

        }
        static Node marge(Node a , Node b){
            Node t1=a;
            Node t2=b;
            Node h=new Node(100);
            Node t=h;
            while (t1!=null && t2!=null){
                if(t1.data<t2.data){
                    t.next=t1;
                    t=t1;
                    t1=t1.next;

                }else{
                    t.next=t2;
                    t=t2;
                    t2=t2.next;
                }
            }
            if(t1==null){
                t.next=t2;
            }else{
                t.next=t1;
            }
            return h.next;
        }
        static  void display(Node head){

            while(head!=null){
                System.out.print(head.data+" ");
                head=head.next;
            }

        }

        public static void main(String[] args) {
            Node a=new Node(1);
            a.next=new Node(3);
            a.next.next=new Node(5);
            a.next.next.next=new Node(7);

            Node b=new Node(2);
            b.next=new Node(4);
            b.next.next=new Node(6);


           display(marge(a,b));

        }
    }
}
