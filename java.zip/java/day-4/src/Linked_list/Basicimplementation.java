public class Basicimplementation {
    public static class Node{
        int data;
        Node next;
        Node(int data){
            this.data=data;
        }
    }
    public static class linkedlist {
        Node head = null;
        Node tail = null;

        void insertAtend(int val) {
            Node temp = new Node(val);
            if (head == null) {
                head = temp;
                tail = temp;
            } else {
                tail.next = temp;
                tail = temp;
            }
        }
        void deleteAtstart(){
            Node temp=head;
            temp=head.next;
            head=temp;

        }

        void display() {

            Node temp = head;
            while (temp != null) {
                System.out.print(temp.data +"->");
                temp = temp.next;
            }
        }
    }

    public static void main(String[] args) {
        linkedlist ll=new linkedlist();
        ll.insertAtend(1);
        ll.insertAtend(2);
        ll.insertAtend(3);
        ll.insertAtend(4);
        ll.insertAtend(5);
        ll.display();
        System.out.println();
        ll.deleteAtstart();
        ll.display();
    }

}
