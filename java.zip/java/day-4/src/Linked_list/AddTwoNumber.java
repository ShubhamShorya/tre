public class AddTwoNumber {

    // Definition for singly-linked list node
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Method to add two numbers represented by linked lists
    public static Node addTwoNumbers(Node l1, Node l2) {
        Node dummyHead = new Node(0); // Dummy node to act as the head of the result list
        Node p = l1, q = l2, current = dummyHead;
        int carry = 0;

        while (p != null || q != null) {
            int x = (p != null) ? p.data : 0;
            int y = (q != null) ? q.data : 0;
            int sum = carry + x + y;
            carry = sum / 10;
            current.next = new Node(sum % 10);
            current = current.next;

            if (p != null) p = p.next;
            if (q != null) q = q.next;
        }

        // Check for remaining carry
        if (carry > 0) {
            current.next = new Node(carry);
        }

        return dummyHead.next;
    }

    public static void main(String[] args) {
        // Create first number: 342 (represented as 2 -> 4 -> 3)
        Node l1 = new Node(2);
        l1.next = new Node(4);
        l1.next.next = new Node(3);

        // Create second number: 465 (represented as 5 -> 6 -> 4)
        Node l2 = new Node(5);
        l2.next = new Node(6);
        l2.next.next = new Node(4);

        // Add the two numbers
        Node result = addTwoNumbers(l1, l2);

        // Print the result
        System.out.print("Result: ");
        printList(result); // Should print 7 -> 0 -> 8
    }

    // Method to print the linked list
    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

