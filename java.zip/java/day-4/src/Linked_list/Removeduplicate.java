public class Removeduplicate {
     static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;

        }
    }
        public static void duplicate(Node head){
            if(head==null){
                return;
            }
            Node temp=head;
            while(temp!=null && temp.next!=null){
                if(temp.data==temp.next.data){
                    temp.next=temp.next.next;
                }else{
                    temp=temp.next;
                }
            }
        }
        private static void display(Node a) {
            Node temp=a;
            while(temp!=null){
                System.out.print(temp.data+" ");
                temp=temp.next;
            }

        }

        public static void main(String[] args) {
            Node a = new Node(1);
            Node b = new Node(1);
            Node c = new Node(3);
            Node d = new Node(3);
            Node e = new Node(5);
            Node f = new Node(6);
            a.next = b;
            b.next = c;
            c.next = d;
            d.next = e;
            e.next = f;
            f.next = null;
            System.out.println("original data");
            display(a);
            System.out.println("after removal");
            duplicate(a);
            display(a);

        }
}
