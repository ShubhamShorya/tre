public class Rotatell {
    public static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    static void display(Node head) {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
    public static Node rotate(Node head , int k){
        if(head==null || head.next==null || k ==0){
            return head;
        }
        Node curr=head;
        int length=1;
        while(curr.next!=null){
            curr=curr.next;
            length++;
        }
        curr.next=head;
        k=k%length;
        int Snewhead=length-k;
        Node newtail=head;
        for(int i=1 ; i<Snewhead ; i++){
            newtail=newtail.next;
        }
        Node newhead=newtail.next;
        newtail.next=null;

        return newhead;


    }


    public static void main(String[] args) {
        Node a = new Node(1);
        Node b = new Node(2);
        Node c = new Node(3);
        Node d = new Node(4);
        Node e = new Node(5);
        Node f = new Node(6);
        a.next = b;
        b.next = c;
        c.next = d;
        d.next = e;
        e.next = f;
        f.next = null;

        System.out.print("Original list: ");
        display(a);
        Node rotatedll=rotate(a, 2);
        System.out.print("after rotation : ");
        display(rotatedll);


    }

}
