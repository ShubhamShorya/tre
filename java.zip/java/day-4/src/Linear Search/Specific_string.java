//Q2.Specific string
import java.util.Scanner;
import java.util.HashSet;

public class Specific_string {

    static int StringSearch(String[]fruits,String target){
        for(int i=0;i<fruits.length;i++){
            if(fruits[i].equals(target)){
                return i;
            }
        }
        return -1;
    }




    public static void main(String[] args) {
        String[] fruits={"banana","guva","apple","mango"};
        String target="banana";
        int k=StringSearch(fruits, target);
        if(k!=-1){
            System.out.println("Fruit found at array index "+ k);
        }
        else{
            System.out.println("Fruit not found");
        }
    }

}
