//Write a method to find all the indices where a specific integer appears in array .
// Return a list of indicies
import java.util.*;
public class All_occ_list {
    public static int All_indicies(List<Integer> num,int tar){
        List<Integer>ans= new ArrayList<Integer>();
        for(int i=0;i<num.size();i++){
            if(num.get(i)==tar){
                ans.add(i);
            }

        }
        for(int i=0;i<ans.size();i++){
            System.out.print(ans.get(i)+ " ");
        }
        return 1;
    }



    public static void main(String[] args) {
        List<Integer> number=List.of(12,23,55,67,12);
        int val=12;
        int k=All_indicies( number,val);

    }
}
