//Find maximum element in an array using linear search

public class Max_element {
    public static int Max_element(int[]arr){
        int max=arr[0];
        for(int i=0;i<arr.length;i++){
            if(arr[i]>arr[0]){
                max =arr[i];
            }
        }
        return max;

    }

    public static void main(String[] args) {
        int[] arr={22,34,56,1,23,321};
        System.out.println(Max_element(arr));

    }
}
