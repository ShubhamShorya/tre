//Count occurence of charcter in string
import java.util.Arrays;

public class Char_occ {
    static int Char_occ(String str,char k){
        char[] nw = str.toCharArray();
        int count=0;
        for(int i=0;i<nw.length;i++) {
            if (nw[i]==k){
                count++;
            }


        }
         return count;
    }


    public static void main(String[] args) {
        String str= "Hello, world";
        char k='o';
        int ct=Char_occ(str, k);
        System.out.println(ct+" time the character occured");

    }
}
