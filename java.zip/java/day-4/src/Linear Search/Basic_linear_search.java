public class Basic_linear_search {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
