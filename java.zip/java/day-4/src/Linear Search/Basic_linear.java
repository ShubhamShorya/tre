//Q1 basic linear search
import org.w3c.dom.ls.LSOutput;

import java.util.*;
public class Basic_linear {
    static int linearsearch(int[] arr,int target){
        if(arr.length==0){
            return -1;
        }
        for(int index=0; index<arr.length;index++){
            int element=arr[index];
            if(element==target){
               return index;
            }
        }
        return -1;

    }




    public static void main(String[] args) {
        int[] arr={12,34,2,3,4211,44,56};
        int target = 421;
        int k= linearsearch(arr,target);
        if(k!=-1){
            System.out.println("integer found at array index "+ k);
        }
        else{
            System.out.println("Elemnet not found");
        }


    }
}
