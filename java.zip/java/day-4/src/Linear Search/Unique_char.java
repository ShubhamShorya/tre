//Q7 Implement a method to find the first non-duplicate character in a character in
//a string using linear search
public class Unique_char {
    static char Non_duplicate(String s){
        int count=0;
      char k='0';
        for(int i=0;i<s.length();i++) {
            char currChar=s.charAt(i);
            if(s.indexOf(currChar)==s.lastIndexOf(currChar)){
                return currChar;
            }

        }
        return '\0';

    }

    public static void main(String[] args) {
        String str="HelloWorld";
        System.out.println( Non_duplicate(str));


    }
}
