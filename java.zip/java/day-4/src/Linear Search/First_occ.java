//First occurance of a number
import java.util.*;

public class First_occ {

    static int first_occ(List<Integer> number,int target){
        for(int i=0;i<number.size();i++){
            if(number.get(i)==target){
                return i;
            }
        }
        return -1;
    }


    public static void main(String[] args) {
        List<Integer> number=List.of(10,20,30,4,5,5,10);
        int target=4;
       int k= first_occ(number,target);
       if(k!=-1){
            System.out.println("Yes it first occured at position " + k);
        }
       else{
           System.out.println("number does not exist" );
       }

    }
}
