// Find the Position of a Target Element
//○ Write a method to find the position of a target element in a sorted array. If the
//element is not found, return -1.

import java.util.*;
public class Element_at_position {
    public static void main(String[] args) {
        Scanner keyboard=new Scanner(System.in);
        int target,index;
        int [] numArray={1,4,6,7,8,10,14,16,17,26,30,35,38,41};

        System.out.print("What do you want to find?");
        target=keyboard.nextInt();
        index=binarySearch(numArray, target);
        System.out.println("The element is found at index:"+index);
    }

    static int binarySearch(int [] numArray, int target){
        int left=0;
        int right=numArray.length-1;
        while(left<=right){
            int mid=left+(right-left)/2;
            if(numArray[mid]==target){
                return mid;
            }else if(target<numArray[mid]){
                right=mid-1;
            }else{
                left=mid+1;
            }
        }
        return -1;
    }
}
