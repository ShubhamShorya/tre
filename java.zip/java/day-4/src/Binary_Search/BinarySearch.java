//Basic Binary Search in Sorted Array
//○ Implement a binary search algorithm to find a specific element in a sorted array
//of integers. Return the index of the element if found; otherwise, return -1

import java.util.Arrays;

    class BinarySearch {
        int binarySearch(int array[], int x, int low, int high) {
            while (low <= high) {
                int mid = low + (high - low) / 2;

                if (array[mid] == x)
                    return mid;

                if (array[mid] < x)
                    low = mid + 1;

                else
                    high = mid - 1;
            }

            return -1;
        }

        public static void main(String args[]) {
            BinarySearch ob = new BinarySearch();
            int[] array = { 3, 4, 5, 16, 117, 8, 9 };
            Arrays.sort(array);
            int n = array.length;
            int x = 4;
            int result = ob.binarySearch(array, x, 0, n - 1);
            if (result == -1)
                System.out.println("Not found");
            else
                System.out.println("Element found at index " + result);
        }
    }

