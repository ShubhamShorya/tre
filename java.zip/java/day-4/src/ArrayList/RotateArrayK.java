import java.util.ArrayList;
import java.util.Scanner;
public class RotateArrayK {
            public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);
                System.out.println("enter arraylist size: ");
                int n = sc.nextInt();
                System.out.println("enter kkk postions: ");
                int k = sc.nextInt();

                ArrayList<Integer> numbers = new ArrayList<>();

                for (int i = 0; i < n; i++) {
                    numbers.add(sc.nextInt());
                }
                rotateArray(numbers, k);
                ArrayList<Integer> ans = rotateArray(numbers, k);
                for (Integer x : ans) {
                    System.out.print(x + " ");
                }
            }

            static ArrayList<Integer> rotateArray(ArrayList<Integer> numbers, int k) {
                for (int i = 0; i < k; i++) {
                    numbers.add(0, numbers.get(numbers.size() - 1));
                    numbers.remove(numbers.size() - 1);
                }
                ArrayList<Integer> numbers1 = numbers;
//                System.out.println("numbers: " + numbers1.toString());
                return numbers1;
            }
        }

