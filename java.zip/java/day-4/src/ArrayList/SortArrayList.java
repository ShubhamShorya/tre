import java.util.ArrayList;

public class SortArrayList {
    public static void main(String[] args) {
        ArrayList<Integer>list1=new ArrayList<>();
        list1.add(44);
        list1.add(25);
        list1.add(9);
        list1.add(78);
        list1.add(2);
        for(int i=0;i<list1.size()-1;i++){
        for (int j=0;j<list1.size()-1-i;j++){
            if(list1.get(j)>list1.get(j+1)){
            int temp= list1.get(j);
            list1.set(j,list1.get(j+1));
            list1.set(j+1,temp);}
        }
        }
        System.out.println(list1);
    }
}
