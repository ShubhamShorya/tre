import java.util.ArrayList;

public class LargeSmallEle {
    public static void main(String[] args) {
        ArrayList<Integer> list1=new ArrayList<>();
        list1.add(44);
        list1.add(25);
        list1.add(9);
        list1.add(78);
        list1.add(2);
        int min=Integer.MAX_VALUE;
        int max=Integer.MIN_VALUE;
        for(int num:list1){
            if (num<min){
                min=num;
            }
            if(num>max){
                max=num;
            }
        }
        System.out.println("Smallest: "+min);
        System.out.println("Largest: "+max);
    }
}
