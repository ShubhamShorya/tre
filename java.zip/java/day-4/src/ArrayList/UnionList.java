import java.util.ArrayList;

public class UnionList {
    public static void main(String[] args) {
        ArrayList<Integer>ar=new ArrayList<>();
        ArrayList<Integer>ar1=new ArrayList<>();
        ar.add(41);ar.add(56);ar.add(68);
        ar.add(78);ar.add(31);ar.add(15);
        ar1.add(59);ar1.add(56);ar1.add(78);
        ar1.add(70);ar1.add(31);ar1.add(15);
        ar.removeIf(ar1::contains);
        ar.addAll(ar1);
        System.out.println(ar);
    }
}
