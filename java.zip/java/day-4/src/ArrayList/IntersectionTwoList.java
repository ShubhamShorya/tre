import java.util.ArrayList;

public class IntersectionTwoList {
    public static void main(String[] args) {
        ArrayList<Integer> ar = new ArrayList<Integer>();
        ArrayList<Integer> ar1 = new ArrayList<Integer>();
        ArrayList<Integer> ar2 = new ArrayList<Integer>();
        ar.add(41);ar.add(56);ar.add(68);
        ar.add(78);ar.add(31);ar.add(15);
        ar1.add(59);ar1.add(56);ar1.add(78);
        ar1.add(70);ar1.add(31);ar1.add(15);
        for (Integer i: ar) {
                if (ar1.contains(i)) {
                    ar2.add(i);

            }
        }
            System.out.println(ar2);



}}
