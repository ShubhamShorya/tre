import java.util.ArrayList;

public class RemoveDuplicate {
    public static void main(String[] args) {
        ArrayList<Integer> ar = new ArrayList<Integer>();
        ar.add(31);
        ar.add(56);
        ar.add(78);
        ar.add(78);
        ar.add(31);
        ar.add(15);
        for (int i = 0; i < ar.size(); i++) {
            for (int j = i + 1; j < ar.size(); j++) {
                if (ar.get(i).equals(ar.get(j))) {
                    ar.remove(j);

                }
            }
        }
        System.out.println(ar);

    }}
