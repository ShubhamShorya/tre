import java.util.ArrayList;

public class CheckPalindrome {
    static boolean Palindrome(ArrayList<Character> list1) {
        int left = 0;
        int right = list1.size() - 1;
        while (left < right) {
            if (list1.get(left) != list1.get(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
    public static void main(String[] args) {
        ArrayList<Character> list1 = new ArrayList<>();
        list1.add('a');
        list1.add('b');
        list1.add('c');
        list1.add('t');
        list1.add('a');
        boolean Palind=Palindrome(list1);
        if(Palind){
            System.out.println("Its a Palindrome");
        }
        else{
            System.out.println("its not Palindrome");
        }

    }
}
