import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class FirstElementRepeat {
    public static void main(String[] args) {
        int n;
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        HashMap<Integer,Integer> h=new HashMap<>();
        ArrayList<Integer> a=new ArrayList<>();
        for(int i=0;i<n;i++)
        {
            int k=sc.nextInt();
            a.add(k);
            h.put(k,h.getOrDefault(k,0)+1);
        }
        int ans=-1;
        for(int i=0;i<n;i++)
        {
            if(h.get(a.get(i))==1)
            {
                ans=a.get(i);
                break;
            }
        }
        System.out.println("first non repeating element is  "+ans);
    }
}
