import java.util.ArrayList;

public class ReverseArrList {
    public static void main(String[] args) {
        ArrayList<Integer>list1=new ArrayList<>();

        list1.add(199);
        list1.add(23);
        list1.add(33);
        list1.add(44);
        list1.add(55);
        ArrayList<Integer>list2=new ArrayList<>();
        for(int i=list1.size()-1;i>=0;i--){
            list2.add(list1.get(i));
        }
     System.out.println(list2);
    }
}
