public class Policy {
    private String policyNumber;
    private String policyType;
    private double policyAmount;

    public Policy(String policyNumber, String policyType, double policyAmount) {
        this.policyNumber = policyNumber;
        this.policyType = policyType;
        this.policyAmount = policyAmount;
    }

    // Getters and setters

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public double getPolicyAmount() {
        return policyAmount;
    }

    public void setPolicyAmount(double policyAmount) {
        this.policyAmount = policyAmount;
    }

    @Override
    public String toString() {
        return "Policy{" +
                "policyNumber='" + policyNumber + '\'' +
                ", policyType='" + policyType + '\'' +
                ", policyAmount=" + policyAmount +
                '}';
    }
}
