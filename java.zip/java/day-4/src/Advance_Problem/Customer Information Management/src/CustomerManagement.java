import java.util.ArrayList;
import java.util.Scanner;

public class CustomerManagement {
    private ArrayList<Customer> customers;

    public CustomerManagement() {
        this.customers = new ArrayList<>();
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public Customer getCustomerById(String customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId().equals(customerId)) {
                return customer;
            }
        }
        return null;
    }

    public void updateCustomerDetails(String customerId, String name, String address, String phoneNumber) {
        Customer customer = getCustomerById(customerId);
        if (customer != null) {
            customer.setName(name);
            customer.setAddress(address);
            customer.setPhoneNumber(phoneNumber);
        } else {
            System.out.println("Customer not found.");
        }
    }

    public void printCustomerPolicies(String customerId) {
        Customer customer = getCustomerById(customerId);
        if (customer != null) {
            System.out.println("Policies for customer ID " + customerId + ":");
            for (Policy policy : customer.getPolicies()) {
                System.out.println(policy);
            }
        } else {
            System.out.println("Customer not found.");
        }
    }

    public static void main(String[] args) {
        CustomerManagement management = new CustomerManagement();
        Scanner scanner = new Scanner(System.in);
        String customerId, name, address, phoneNumber;

        while (true) {
            System.out.println("1. Add new customer");
            System.out.println("2. Update customer details");
            System.out.println("3. Retrieve all policies for a customer");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextLine();
                    System.out.print("Enter name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter address: ");
                    address = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    phoneNumber = scanner.nextLine();
                    Customer customer = new Customer(customerId, name, address, phoneNumber);
                    management.addCustomer(customer);
                    System.out.println("Customer added.");
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextLine();
                    System.out.print("Enter new name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new address: ");
                    address = scanner.nextLine();
                    System.out.print("Enter new phone number: ");
                    phoneNumber = scanner.nextLine();
                    management.updateCustomerDetails(customerId, name, address, phoneNumber);
                    break;
                case 3:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextLine();
                    management.printCustomerPolicies(customerId);
                    break;
                case 4:
                    System.out.println("Exiting.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
