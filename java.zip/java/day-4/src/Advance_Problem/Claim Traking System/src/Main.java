//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        ClaimTrackingSystem system = new ClaimTrackingSystem();

        // Add new claims
        system.addClaim(new Claim("C001", "P001", "John Doe", 1500.0, "pending"));
        system.addClaim(new Claim("C002", "P002", "Jane Smith", 2000.0, "approved"));
        system.addClaim(new Claim("C003", "P003", "Alice Johnson", 1000.0, "rejected"));

        // Update claim status
        system.updateClaimStatus("C001", "approved");

        // Generate status report
        system.generateStatusReport();

        // Print all claims
        system.printAllClaims();
    }
}