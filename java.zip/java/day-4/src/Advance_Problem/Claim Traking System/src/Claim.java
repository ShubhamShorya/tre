 import java.util.ArrayList;
import java.util.List;

 public class Claim {
        private String claimNumber;
        private String policyNumber;
        private String claimantName;
        private double claimAmount;
        private String status;

        public Claim(String claimNumber, String policyNumber, String claimantName, double claimAmount, String status) {
            this.claimNumber = claimNumber;
            this.policyNumber = policyNumber;
            this.claimantName = claimantName;
            this.claimAmount = claimAmount;
            this.status = status;
        }

        public String getClaimNumber() {
            return claimNumber;
        }

        public String getPolicyNumber() {
            return policyNumber;
        }

        public String getClaimantName() {
            return claimantName;
        }

        public double getClaimAmount() {
            return claimAmount;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        @Override
        public String toString() {
            return "Claim{" +
                    "claimNumber='" + claimNumber + '\'' +
                    ", policyNumber='" + policyNumber + '\'' +
                    ", claimantName='" + claimantName + '\'' +
                    ", claimAmount=" + claimAmount +
                    ", status='" + status + '\'' +
                    '}';
        }
    }

