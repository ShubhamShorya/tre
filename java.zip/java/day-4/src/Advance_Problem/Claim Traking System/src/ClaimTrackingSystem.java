import java.util.*;
public class ClaimTrackingSystem {
    private List<Claim> claims;

    public ClaimTrackingSystem() {
        this.claims = new ArrayList<>();
    }

    public void addClaim(Claim claim) {
        claims.add(claim);
    }

    public void updateClaimStatus(String claimNumber, String newStatus) {
        for (Claim claim : claims) {
            if (claim.getClaimNumber().equals(claimNumber)) {
                claim.setStatus(newStatus);
                return;
            }
        }
        System.out.println("Claim with claim number " + claimNumber + " not found.");
    }

    public void generateStatusReport() {
        int pendingCount = 0, approvedCount = 0, rejectedCount = 0;

        for (Claim claim : claims) {
            switch (claim.getStatus()) {
                case "pending":
                    pendingCount++;
                    break;
                case "approved":
                    approvedCount++;
                    break;
                case "rejected":
                    rejectedCount++;
                    break;
            }
        }

        System.out.println("Claim Status Report:");
        System.out.println("Pending: " + pendingCount);
        System.out.println("Approved: " + approvedCount);
        System.out.println("Rejected: " + rejectedCount);
    }

    public void printAllClaims() {
        for (Claim claim : claims) {
            System.out.println(claim);
        }
    }
}
