import java.util.*;
public class InsurancePolicyManager {
    private ArrayList<InsurancePolicy> policies;

    public InsurancePolicyManager() {
        this.policies = new ArrayList<>();
    }

    // Add a new policy
    public void addPolicy(InsurancePolicy policy) {
        policies.add(policy);
    }

    // Remove a policy by policy number
    public boolean removePolicy(String policyNumber) {
        for (InsurancePolicy policy : policies) {
            if (policy.getPolicyNumber().equals(policyNumber)) {
                policies.remove(policy);
                return true;
            }
        }
        return false;
    }

    // Update policy details
    public boolean updatePolicy(String policyNumber, String policyholderName, String insuranceType, double coverageAmount) {
        for (InsurancePolicy policy : policies) {
            if (policy.getPolicyNumber().equals(policyNumber)) {
                policy.setPolicyholderName(policyholderName);
                policy.setInsuranceType(insuranceType);
                policy.setCoverageAmount(coverageAmount);
                return true;
            }
        }
        return false;
    }

    // List all policies of a specific type
    public ArrayList<InsurancePolicy> listPoliciesByType(String insuranceType) {
        ArrayList<InsurancePolicy> result = new ArrayList<>();
        for (InsurancePolicy policy : policies) {
            if (policy.getInsuranceType().equalsIgnoreCase(insuranceType)) {
                result.add(policy);
            }
        }
        return result;
    }

    // List all policies
    public ArrayList<InsurancePolicy> listAllPolicies() {
        return policies;
    }
}
