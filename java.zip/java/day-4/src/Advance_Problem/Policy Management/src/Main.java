import java.util.*;
public class Main {
    public static void main(String[] args) {
        InsurancePolicyManager manager = new InsurancePolicyManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Policy");
            System.out.println("2. Remove Policy");
            System.out.println("3. Update Policy");
            System.out.println("4. List Policies by Type");
            System.out.println("5. List All Policies");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Policy Number: ");
                    String policyNumber = scanner.nextLine();
                    System.out.print("Enter Policyholder Name: ");
                    String policyholderName = scanner.nextLine();
                    System.out.print("Enter Insurance Type: ");
                    String insuranceType = scanner.nextLine();
                    System.out.print("Enter Coverage Amount: ");
                    double coverageAmount = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    manager.addPolicy(new InsurancePolicy(policyNumber, policyholderName, insuranceType, coverageAmount));
                    break;
                case 2:
                    System.out.print("Enter Policy Number to Remove: ");
                    policyNumber = scanner.nextLine();
                    if (manager.removePolicy(policyNumber)) {
                        System.out.println("Policy removed successfully.");
                    } else {
                        System.out.println("Policy not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter Policy Number to Update: ");
                    policyNumber = scanner.nextLine();
                    System.out.print("Enter New Policyholder Name: ");
                    policyholderName = scanner.nextLine();
                    System.out.print("Enter New Insurance Type: ");
                    insuranceType = scanner.nextLine();
                    System.out.print("Enter New Coverage Amount: ");
                    coverageAmount = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    if (manager.updatePolicy(policyNumber, policyholderName, insuranceType, coverageAmount)) {
                        System.out.println("Policy updated successfully.");
                    } else {
                        System.out.println("Policy not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter Insurance Type to List: ");
                    insuranceType = scanner.nextLine();
                    ArrayList<InsurancePolicy> policiesByType = manager.listPoliciesByType(insuranceType);
                    if (policiesByType.isEmpty()) {
                        System.out.println("No policies found for the given type.");
                    } else {
                        for (InsurancePolicy policy : policiesByType) {
                            System.out.println(policy);
                        }
                    }
                    break;
                case 5:
                    ArrayList<InsurancePolicy> allPolicies = manager.listAllPolicies();
                    if (allPolicies.isEmpty()) {
                        System.out.println("No policies available.");
                    } else {
                        for (InsurancePolicy policy : allPolicies) {
                            System.out.println(policy);
                        }
                    }
                    break;
                case 6:
                    scanner.close();
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}

