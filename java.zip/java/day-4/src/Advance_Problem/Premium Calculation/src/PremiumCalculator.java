import java.util.ArrayList;

public class PremiumCalculator {
    private ArrayList<Policy> policies;

    public PremiumCalculator() {
        this.policies = new ArrayList<>();
    }

    public void addPolicy(Policy policy) {
        policies.add(policy);
    }

    public void calculatePremiums() {
        for (Policy policy : policies) {
            double calculatedPremium = policy.getBasePremium() * policy.getRiskFactor();
            policy.setCalculatedPremium(calculatedPremium);
        }
    }

    public void updatePolicy(String policyNumber, double newRiskFactor) {
        for (Policy policy : policies) {
            if (policy.getPolicyNumber().equals(policyNumber)) {
                policy.setRiskFactor(newRiskFactor);
                double calculatedPremium = policy.getBasePremium() * newRiskFactor;
                policy.setCalculatedPremium(calculatedPremium);
                break;
            }
        }
    }

    public void generatePremiumReport() {
        for (Policy policy : policies) {
            System.out.println(policy);
        }
    }
}
