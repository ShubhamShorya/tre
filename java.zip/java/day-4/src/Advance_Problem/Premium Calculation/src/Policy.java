public class Policy {
    private String policyNumber;
    private String policyType;
    private double basePremium;
    private double riskFactor;
    private double calculatedPremium;

    public Policy(String policyNumber, String policyType, double basePremium, double riskFactor) {
        this.policyNumber = policyNumber;
        this.policyType = policyType;
        this.basePremium = basePremium;
        this.riskFactor = riskFactor;
        this.calculatedPremium = 0.0;
    }

    // Getters and setters
    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public double getBasePremium() {
        return basePremium;
    }

    public void setBasePremium(double basePremium) {
        this.basePremium = basePremium;
    }

    public double getRiskFactor() {
        return riskFactor;
    }

    public void setRiskFactor(double riskFactor) {
        this.riskFactor = riskFactor;
    }

    public double getCalculatedPremium() {
        return calculatedPremium;
    }

    public void setCalculatedPremium(double calculatedPremium) {
        this.calculatedPremium = calculatedPremium;
    }

    @Override
    public String toString() {
        return "Policy{" +
                "policyNumber='" + policyNumber + '\'' +
                ", policyType='" + policyType + '\'' +
                ", basePremium=" + basePremium +
                ", riskFactor=" + riskFactor +
                ", calculatedPremium=" + calculatedPremium +
                '}';
    }
}