//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        PremiumCalculator calculator = new PremiumCalculator();

        // Add some policies
        Policy policy1 = new Policy("P001", "Life", 1000.0, 1.2);
        Policy policy2 = new Policy("P002", "Health", 500.0, 1.5);
        Policy policy3 = new Policy("P003", "Auto", 300.0, 2.0);

        calculator.addPolicy(policy1);
        calculator.addPolicy(policy2);
        calculator.addPolicy(policy3);

        // Calculate premiums
        calculator.calculatePremiums();

        // Update a policy risk factor and recalculate
        calculator.updatePolicy("P002", 1.8);

        // Generate a report of all calculated premiums
        calculator.generatePremiumReport();
    }
}