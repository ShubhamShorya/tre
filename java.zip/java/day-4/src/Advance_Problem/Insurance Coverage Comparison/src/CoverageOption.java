public class CoverageOption {
    private String coverageType;
    private double coverageAmount;
    private double premium;

    public CoverageOption(String coverageType, double coverageAmount, double premium) {
        this.coverageType = coverageType;
        this.coverageAmount = coverageAmount;
        this.premium = premium;
    }

    // Getters and setters
    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public double getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }

    @Override
    public String toString() {
        return "CoverageOption{" +
                "coverageType='" + coverageType + '\'' +
                ", coverageAmount=" + coverageAmount +
                ", premium=" + premium +
                '}';
    }
}

