import java.util.ArrayList;
import java.util.Comparator;

public class CoverageComparator {
    private ArrayList<CoverageOption> coverageOptions;

    public CoverageComparator() {
        this.coverageOptions = new ArrayList<>();
    }

    public void addCoverageOption(CoverageOption option) {
        coverageOptions.add(option);
    }

    public CoverageOption recommendBestOption() {
        if (coverageOptions.isEmpty()) {
            return null;
        }

        return coverageOptions.stream()
                .max(Comparator.comparingDouble(CoverageOption::getCoverageAmount)
                        .thenComparingDouble(CoverageOption::getPremium))
                .orElse(null);
    }

    public ArrayList<CoverageOption> getCoverageOptions() {
        return coverageOptions;
    }
}
