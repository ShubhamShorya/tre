//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        CoverageComparator comparator = new CoverageComparator();

        // Add some coverage options
        CoverageOption option1 = new CoverageOption("Life", 100000.0, 1200.0);
        CoverageOption option2 = new CoverageOption("Health", 50000.0, 1500.0);
        CoverageOption option3 = new CoverageOption("Auto", 30000.0, 900.0);

        comparator.addCoverageOption(option1);
        comparator.addCoverageOption(option2);
        comparator.addCoverageOption(option3);

        // Recommend the best option
        CoverageOption bestOption = comparator.recommendBestOption();
        System.out.println("Recommended Coverage Option: " + bestOption);

        // Print all coverage options
        System.out.println("\nAll Coverage Options:");
        for (CoverageOption option : comparator.getCoverageOptions()) {
            System.out.println(option);
        }
    }
}