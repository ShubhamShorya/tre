package org.example.Problem1;

public class Car {

    private Engine engine;

    public Car(Engine engine) {
        this.engine = engine;
    }

    public void Drive()
    {
        System.out.println("Car is driving with " + engine.toString());
    }
}
