package org.example.Problem5;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "org.example.Problem5")
public class AppConfig {

    @Bean
    public Engine engine() {
        Engine engine = new Engine();
        engine.setType("V8"); // Set the type property here
        return engine;
    }
}

