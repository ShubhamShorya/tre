package org.example.Problem5;

import org.springframework.stereotype.Component;

@Component
public class Engine {
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void run() {
        System.out.println("Engine is running");
    }

    @Override
    public String toString() {
        return "Engine Type: " + type;
    }
}

