package org.example.Problem3;



public class Car {

    private Engine engine;

      public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public void Drive()
    {
        engine.run();
        System.out.println("Car is driving with " + engine.toString());
    }
}
