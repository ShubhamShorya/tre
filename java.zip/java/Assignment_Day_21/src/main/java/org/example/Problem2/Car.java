package org.example.Problem2;

import org.example.Problem1.Engine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {

    private Engine engine;
@Autowired
    public Car(Engine engine) {
        this.engine = engine;
    }

    public void Drive()
    {
        System.out.println("Car is driving with " + engine.toString());
    }
}
