class Task {
    int taskId;
    String description;
    String dueDate;
    boolean completed;

    public Task(int taskId, String description, String dueDate, boolean completed) {
        this.taskId = taskId;
        this.description = description;
        this.dueDate = dueDate;
        this.completed = completed;
    }

    @Override
    public String toString() {
        return "Task ID: " + taskId + ", Description: " + description + ", Due Date: " + dueDate + ", Completed: " + completed;
    }
}

