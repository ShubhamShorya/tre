import java.util.*;
import java.io.*;

public class TaskManagementSystem {
    private static List<Task> tasks = new ArrayList<>();
    private static final String FILE_NAME = "tasks.json";

    public static void main(String[] args) {
        loadTasks();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Add a New Task");
            System.out.println("2. View All Tasks");
            System.out.println("3. Update Task Details");
            System.out.println("4. Delete a Task");
            System.out.println("5. Mark Task as Completed");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addTask(scanner);
                    break;
                case 2:
                    viewAllTasks();
                    break;
                case 3:
                    updateTask(scanner);
                    break;
                case 4:
                    deleteTask(scanner);
                    break;
                case 5:
                    markTaskAsCompleted(scanner);
                    break;
                case 6:
                    saveTasks();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addTask(Scanner scanner) {
        System.out.print("Enter Task ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter Description: ");
        String description = scanner.nextLine();

        System.out.print("Enter Due Date: ");
        String dueDate = scanner.nextLine();

        System.out.print("Is Completed (true/false): ");
        boolean completed = scanner.nextBoolean();

        tasks.add(new Task(id, description, dueDate, completed));
        System.out.println("Task added successfully!");
    }

    private static void viewAllTasks() {
        for (Task task : tasks) {
            System.out.println(task);
        }
    }

    private static void updateTask(Scanner scanner) {
        System.out.print("Enter Task ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (Task task : tasks) {
            if (task.taskId == id) {
                System.out.print("Enter new Description: ");
                task.description = scanner.nextLine();

                System.out.print("Enter new Due Date: ");
                task.dueDate = scanner.nextLine();

                System.out.println("Task updated successfully!");
                return;
            }
        }
        System.out.println("Task not found.");
    }

    private static void deleteTask(Scanner scanner) {
        System.out.print("Enter Task ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        tasks.removeIf(task -> task.taskId == id);
        System.out.println("Task deleted successfully!");
    }

    private static void markTaskAsCompleted(Scanner scanner) {
        System.out.print("Enter Task ID to mark as completed: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (Task task : tasks) {
            if (task.taskId == id) {
                task.completed = true;
                System.out.println("Task marked as completed!");
                return;
            }
        }
        System.out.println("Task not found.");
    }

    private static void loadTasks() {

    }

    private static void saveTasks() {

    }
}
