package com.AssignmentDay24.InsuranceManagementSystem.DTO;

import com.AssignmentDay24.InsuranceManagementSystem.Entity.Agent;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.Claim;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.Policy;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PolicyDTO {

    private Long id;
    private Long policyNumber;
    private String type;
    private List<ClaimDTO> claims;
    private Agent agent;
    private PolicyHolderDTO policyHolder;

    public PolicyDTO(Policy policy)
    {
        this.id = policy.getId();
        this.policyNumber=policy.getPolicyNumber();
        this.type=policy.getType();
        this.claims=policy.getClaims().stream()
                .map(ClaimDTO::new)
                .collect(Collectors.toList());
        this.agent=policy.getAgent();
        this.policyHolder=new PolicyHolderDTO(policy.getPolicyHolder());
    }
}
