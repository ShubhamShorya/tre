package com.AssignmentDay24.InsuranceManagementSystem.Service;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.LoginDTO;
import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyDTO;
import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyHolderDTO;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.Policy;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import com.AssignmentDay24.InsuranceManagementSystem.Exception.ResourceNotFoundException;
import com.AssignmentDay24.InsuranceManagementSystem.Repository.PolicyHolderRepository;
import com.AssignmentDay24.InsuranceManagementSystem.Util.TokenUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PolicyHolderServiceImple implements PolicyHolderService{

    @Autowired
    private PolicyHolderRepository policyHolderRepository;

    @Autowired
    private TokenUtility tokenUtility;
    private PolicyHolderDTO mapToDTO(PolicyHolder policyHolder) {
        return new PolicyHolderDTO(policyHolder);
    }

    public PolicyHolderDTO createPolicyHolder(PolicyHolderDTO policyHolderDTO)
    {
        PolicyHolder policyHolder = new PolicyHolder(policyHolderDTO);
        policyHolderRepository.save(policyHolder);
        return mapToDTO(policyHolder);
    }

    public List<PolicyHolderDTO> getAllPolicyHolder()
    {
        List<PolicyHolderDTO> policyHolderDTOList= policyHolderRepository.findAll().stream()
                .map(this::mapToDTO).collect(Collectors.toList());
        return policyHolderDTOList ;

    }

    public PolicyHolder getPolicyHolderByID(Long Id)
    {
        PolicyHolder policyHolder = policyHolderRepository.findById(Id).orElseThrow(() -> new ResourceNotFoundException("Resource not found"));
        return policyHolder;
    }

    public PolicyHolderDTO updatePolicyHolder(PolicyHolderDTO policyHolderDTO, Long id) {

        PolicyHolder existingPolicyHolder = policyHolderRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Resource not found"));
            existingPolicyHolder.setId(policyHolderDTO.getId());
            existingPolicyHolder.setName(policyHolderDTO.getName());
            existingPolicyHolder.setEmail(policyHolderDTO.getEmail());
            existingPolicyHolder.setPolicies(policyHolderDTO.getPolicies().stream()
                    .map(policyDTO -> new Policy(policyDTO))
                    .collect(Collectors.toList()));
            policyHolderRepository.save(existingPolicyHolder);
            return mapToDTO(existingPolicyHolder);

    }

    public String deletePolicyHolder(Long id)
    {
        policyHolderRepository.deleteById(id);
        return "Policy Holder is updated";
    }
    public ResponseEntity<?> logicUser(LoginDTO loginDTO) {
        PolicyHolder policyHolder = policyHolderRepository.findByName(loginDTO.getName());
        if(policyHolder!=null && policyHolder.getPassword().equals(loginDTO.getPassword())){
            String token = tokenUtility.createToken(policyHolder.getId());

            Map<String, Object> response = new HashMap<>();
            response.put("message","Login Successful");
            response.put("token",token);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            throw new RuntimeException("Login Failed");
        }
    }

    public PolicyHolder getByToken(String token) {
        Long id = tokenUtility.decodeToken(token);
        return getPolicyHolderByID(id);
    }

}
