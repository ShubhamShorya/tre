package com.AssignmentDay24.InsuranceManagementSystem.Entity;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.AddressDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Address")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String street;
    private String City;
    private String state;
    private Long zipcode;

    @ManyToOne
    @JoinColumn(name = "policyHolder_id")
    private PolicyHolder policyHolder;

    public Address(AddressDTO addressDTO)
    {
        this.id= addressDTO.getId();
        this.street= addressDTO.getStreet();
        this.City= addressDTO.getCity();
        this.state=addressDTO.getState();
        this.zipcode= addressDTO.getZipcode();
        this.policyHolder=new PolicyHolder(addressDTO.getPolicyHolder());
    }

}
