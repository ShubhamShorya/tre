package com.AssignmentDay24.InsuranceManagementSystem.Entity;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyHolderDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PolicyHolder")
public class PolicyHolder {

   @Id
   @GeneratedValue (strategy = GenerationType.IDENTITY)

   private Long id;

   private String name;
   private String email;

   @OneToMany(mappedBy = "policyHolder" , cascade = CascadeType.ALL)
   private List<Policy> policies;

   @OneToMany(mappedBy = "policyHolder" , cascade = CascadeType.ALL)
   private List<Address> addresses;
   private String password;

   public PolicyHolder(PolicyHolderDTO policyHolderDTO)
   {
      this.id= policyHolderDTO.getId();
      this.name=policyHolderDTO.getName();
      this.email=policyHolderDTO.getEmail();
      this.policies=policyHolderDTO.getPolicies()
              .stream().map(Policy::new)
              .collect(Collectors.toList());
      this.addresses=policyHolderDTO.getAddresses()
              .stream().map(Address::new)
              .collect(Collectors.toList());
      this.password=policyHolderDTO.getPassword();

   }
}
