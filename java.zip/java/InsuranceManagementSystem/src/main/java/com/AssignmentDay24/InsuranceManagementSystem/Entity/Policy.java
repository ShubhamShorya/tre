package com.AssignmentDay24.InsuranceManagementSystem.Entity;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Policy")
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long policyNumber;
    private String type;

    @OneToMany(mappedBy = "policy" , cascade = CascadeType.ALL)
    private List<Claim> claims;

    @ManyToOne
    @JoinColumn(name = "agent_id")
    private Agent agent;

    @ManyToOne
    @JoinColumn(name ="policyholder_id")
    private PolicyHolder policyHolder;

    public Policy(PolicyDTO policyDTO)
    {
        this.id = policyDTO.getId();
        this.policyNumber=policyDTO.getPolicyNumber();
        this.type=policyDTO.getType();
        this.claims=policyDTO.getClaims()
                .stream().map(Claim::new)
                .collect(Collectors.toList());
        this.agent=policyDTO.getAgent();
        this.policyHolder=new PolicyHolder(policyDTO.getPolicyHolder());
    }


}
