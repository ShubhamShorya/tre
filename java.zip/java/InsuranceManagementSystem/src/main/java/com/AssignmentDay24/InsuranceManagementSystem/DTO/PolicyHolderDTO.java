package com.AssignmentDay24.InsuranceManagementSystem.DTO;

import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyHolderDTO {

    private Long id;
    private String name;
    private String email;
    private List<PolicyDTO> policies;
    private List<AddressDTO> addresses;
    private String password;


    public PolicyHolderDTO(PolicyHolder policyHolder)
    {
        this.id= policyHolder.getId();
        this.name=policyHolder.getName();
        this.email=policyHolder.getEmail();
        this.policies=policyHolder.getPolicies().stream()
                     .map(PolicyDTO::new)
                     .collect(Collectors.toList());
        this.addresses=policyHolder.getAddresses().stream()
                      .map(AddressDTO::new)
                      .collect(Collectors.toList());
        this.password=policyHolder.getPassword();
    }
}
