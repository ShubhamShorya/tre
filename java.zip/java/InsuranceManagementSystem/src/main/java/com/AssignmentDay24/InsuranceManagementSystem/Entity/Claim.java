package com.AssignmentDay24.InsuranceManagementSystem.Entity;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.ClaimDTO;
import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name ="claim")
public class Claim {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long claimNumber;
    private String date;
    private Double amount;
    private String status;
    @ManyToOne
    @JoinColumn(name = "policy_id")
    private Policy policy;

    public Claim(ClaimDTO claimDTO)
    {
        this.id=claimDTO.getId();
        this.claimNumber=claimDTO.getClaimNumber();
        this.date= claimDTO.getDate();
        this.amount=claimDTO.getAmount();
        this.status= claimDTO.getStatus();
        this.policy=new Policy(claimDTO.getPolicy());
    }

}
