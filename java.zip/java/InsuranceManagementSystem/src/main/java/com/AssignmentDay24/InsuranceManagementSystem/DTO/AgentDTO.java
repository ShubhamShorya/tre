package com.AssignmentDay24.InsuranceManagementSystem.DTO;

import com.AssignmentDay24.InsuranceManagementSystem.Entity.Agent;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.Policy;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AgentDTO {

    private long id;
    private String name;
    private String email;
    private List<PolicyDTO> policies;

    public AgentDTO(Agent agent)
    {
        this.id=agent.getId();
        this.name=agent.getName();
        this.email= agent.getEmail();
        this.policies=agent.getPolicies().stream()
                .map(PolicyDTO::new)
                .collect(Collectors.toList());;
    }

}
