package com.AssignmentDay24.InsuranceManagementSystem.DTO;

import com.AssignmentDay24.InsuranceManagementSystem.Entity.Address;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO {

    private Long id;
    private String street;
    private String City;
    private String state;
    private Long zipcode;
    private PolicyHolderDTO policyHolder;

    public AddressDTO(Address address)
    {
        this.id= address.getId();
        this.street= address.getStreet();
        this.City= address.getCity();
        this.state=address.getState();
        this.zipcode= address.getZipcode();
        this.policyHolder=new PolicyHolderDTO(address.getPolicyHolder());
    }
}
