package com.AssignmentDay24.InsuranceManagementSystem.Controller;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyHolderDTO;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import com.AssignmentDay24.InsuranceManagementSystem.Service.PolicyHolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/policy")
@CrossOrigin(origins = "https://localhost:3000")
public class PolicyHolderController {
    @Autowired
    private PolicyHolderService policyHolderService;

    @RequestMapping(value = "/POST", method = RequestMethod.POST)
    public ResponseEntity<String> createPolicyHolder(@RequestBody PolicyHolderDTO policyHolderDTO) {
        policyHolderService.createPolicyHolder(policyHolderDTO);
        return new ResponseEntity<>("policyHolder is created", HttpStatus.CREATED);
    }

    @RequestMapping(value = "/GET/{id}", method = RequestMethod.GET)
    public ResponseEntity<PolicyHolder> getEmployeeById(@PathVariable Long id) {
        return new ResponseEntity<>(policyHolderService.getPolicyHolderByID(id), HttpStatus.OK);
    }

    @RequestMapping(value = "/GET", method = RequestMethod.GET)
    public ResponseEntity<List<PolicyHolderDTO>> getAllEmployees() {
        return new ResponseEntity<>(policyHolderService.getAllPolicyHolder(), HttpStatus.OK);
    }

    @RequestMapping(value = "/PUT/{id}", method = RequestMethod.PUT)
    public String updateEmployee(@RequestBody PolicyHolderDTO policyHolderDTO, @PathVariable Long id) {
        policyHolderService.updatePolicyHolder(policyHolderDTO, id);
        return "employee with id " + id + " is updated";
    }

    @RequestMapping(value = "/DELETE/{id}", method = RequestMethod.DELETE)
    public String deletePolicyHolder(@PathVariable Long id) {

        return policyHolderService.deletePolicyHolder(id);
    }

}