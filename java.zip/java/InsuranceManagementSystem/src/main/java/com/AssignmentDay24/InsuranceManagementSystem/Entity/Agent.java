package com.AssignmentDay24.InsuranceManagementSystem.Entity;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.AgentDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "agent")
public class Agent
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String email;

    @OneToMany(mappedBy = "agent", cascade = CascadeType.ALL)
    private List<Policy> policies;

    public Agent(AgentDTO agentDTO)
    {
        this.id=agentDTO.getId();
        this.name=agentDTO.getName();
        this.email= agentDTO.getEmail();
        this.policies=agentDTO.getPolicies().stream()
                .map(Policy::new)
                .collect(Collectors.toList());
    }
}
