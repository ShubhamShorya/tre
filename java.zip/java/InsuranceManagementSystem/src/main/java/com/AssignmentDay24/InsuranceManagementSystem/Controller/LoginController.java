package com.AssignmentDay24.InsuranceManagementSystem.Controller;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.LoginDTO;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import com.AssignmentDay24.InsuranceManagementSystem.Service.PolicyHolderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
public class LoginController {
    @Autowired
    private PolicyHolderService policyHolderService;

    @PostMapping("/api")
    public ResponseEntity<?> userLogin(@RequestBody LoginDTO loginDTO){
        try{
            return ResponseEntity.ok( policyHolderService.logicUser(loginDTO));

        } catch (Exception exception){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or Password");
        }
    }

    @GetMapping
    public PolicyHolder getBytoken(@RequestHeader String token){
        return policyHolderService.getByToken(token);
    }
}