package com.AssignmentDay24.InsuranceManagementSystem.Service;

import com.AssignmentDay24.InsuranceManagementSystem.DTO.LoginDTO;
import com.AssignmentDay24.InsuranceManagementSystem.DTO.PolicyHolderDTO;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.PolicyHolder;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface PolicyHolderService {

    public PolicyHolderDTO createPolicyHolder(PolicyHolderDTO policyHolderDTO);
    public List<PolicyHolderDTO> getAllPolicyHolder();
    public PolicyHolder getPolicyHolderByID(Long Id);
    public PolicyHolderDTO updatePolicyHolder(PolicyHolderDTO policyHolderDTO, Long id);
    public String deletePolicyHolder(Long id);
    public ResponseEntity<?> logicUser(LoginDTO loginDTO);
    public PolicyHolder getByToken(String token);
}
