package com.AssignmentDay24.InsuranceManagementSystem.DTO;

import com.AssignmentDay24.InsuranceManagementSystem.Entity.Claim;
import com.AssignmentDay24.InsuranceManagementSystem.Entity.Policy;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDTO {

    private Long id;
    private Long claimNumber;
    private String date;
    private Double amount;
    private String status;
    private PolicyDTO policy;

    public ClaimDTO(Claim claim)
    {
        this.id=claim.getId();
        this.claimNumber=claim.getClaimNumber();
        this.date= claim.getDate();
        this.amount=claim.getAmount();
        this.status= claim.getStatus();
        this.policy=new PolicyDTO(claim.getPolicy());
    }
}
