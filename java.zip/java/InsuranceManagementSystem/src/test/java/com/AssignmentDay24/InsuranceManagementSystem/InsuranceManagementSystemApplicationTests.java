package com.AssignmentDay24.InsuranceManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
