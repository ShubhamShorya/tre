//Write a program that multiplies a given integer by 2 using the left shift operator

import java.util.Scanner;

public class Bitwise_shift {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    n=n<<1;
        System.out.println(n);
}
}
