//Problem Statement: Create a program to determine if two given strings are anagrams
//of each other (contain the same characters in different orders

import java.util.*;
import java.util.Arrays;
public class String_Anagram {
    public static void main(String[] args) {
        String str1 = "hello";
        String str2 = "hello";

        if (str1.length() == str2.length()) {
            char[] charArray1 = str1.toCharArray();
            char[] charArray2 = str2.toCharArray();
            Arrays.sort(charArray1);
            Arrays.sort(charArray2);
            boolean result = Arrays.equals(charArray1, charArray2);
            if(result){
                System.out.println(str1 + " and "+str2+" is anagram");
            }
            else{
                System.out.println(str1 + " and "+str2+" is not anagram");
            }

        }
        else{
            System.out.println(str1 + " and "+str2+" is not anagram");
        }
    }

}
