//. Separate Positive and Negative Numbers:
//○ Create a program to separate positive and negative numbers in an array and
//store them in two different arrays.
public class positive_negative {
    public static void main(String[] args) {
        int[] array = {12, 23, -22, 0, 43, 545, -4, -55, 43, 12, 0, -999, -87};
        int l = array.length;
        int[] arrpos = new int[l];
        int[] arrneg = new int[l];
        int i,j,k;
        i=j=k=0;
        for (i = 0; i < l; i++){
            if (array[i] > 0) {
                arrpos[j]=array[i];
                j++;
            }
            else if(array[i] < 0){
                arrneg[k]=array[i];
                k++;
            }
        }
        for (i = 0; i < l; i++){
            System.out.println(arrpos[i]+"\t" + arrneg[i]);
        }
    }
}
