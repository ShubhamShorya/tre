//Write a program that determines if a number is odd or even using the bitwise
//AND operator
import java.util.Scanner;
public class Bitwise_odd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int num = sc.nextInt();
            if((num & 1)==1){
                System.out.println(num+" is odd number");
            }
            else {
                System.out.println(num + " is even number");
            }
        }
    }

