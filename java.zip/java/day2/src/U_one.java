//. Post-Increment and Pre-Increment:
//○ Write a program to demonstrate the difference between post-increment and
//pre-increment operators.
import java.util.Scanner;
public class U_one {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int result=0;
        System.out.println("Enter number");
        int num=sc.nextInt();
        for(int i=0;i<1;i++){
            result+=num ;
        }
        System.out.println(" post increment " +result);
        for(int i=0;i<1;++i){
            result+=num  ;

        }
        System.out.println("Pre increment " + result);

    }

}
