//Palindrome Check:
//11. Problem Statement: Write a program to check if a given string is a palindrome (a string
//that reads the same forward and backward).
//Example: Input: "madam", Output: true
import java.util.*;
public class palindrom {
    public static boolean isPalindrome(String str)
    {
        String rev = "";
        boolean ans = false;

        for (int i = str.length()-1; i >= 0; i--) {
            rev = rev + str.charAt(i);
        }


        if (str.equals(rev)) {
            ans = true;
        }
        return ans;
    }
    public static void main(String[] args)
    {

        String str = "geeg";
        str = str.toLowerCase();
        boolean A = isPalindrome(str);
        System.out.println(A);
    }
}

