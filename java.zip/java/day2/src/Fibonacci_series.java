//. Fibonacci Series
//Fibonacci series is a special type of series in which the next term is the sum of the
//previous two terms. For example, if 0 and 1 are the two previous terms in a series, then
//the next term will be 1(0+1).
import java.util.Scanner;
public class Fibonacci_series {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n =sc.nextInt();
        int a = 0;
        int b= 1;
        int temp=0;
      //  System.out.println(a + b );
        for(int i=1;i<=n;i++){
            System.out.println(a);
            temp=a+b;
            a=b;
            b=temp;
        }


    }
}
