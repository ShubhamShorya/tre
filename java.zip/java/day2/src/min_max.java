//Find Maximum and Minimum:
//○ Write a program to find the maximum and minimum values in an integer array.\

import java.util.*;
public class min_max {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enetr the size of the array");
        int size = sc.nextInt();
        int[] arr = new int[size];


        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int max = arr[0];
        for (int i = 0; i < size; i++) {
            max = Math.max(max, arr[i]);

        }
        System.out.println(max + "is max value");
        int min = arr[0];
        for (int i = 0; i < size; i++) {

            min = Math.min(min, arr[i]);

            // Arrays.sort(arr);
            //  System.out.println(arr[0]+" is min value " +arr[size-1] +" is the smallest value");
        }
        System.out.println(min + "is min value");
    }

}
