

import java.util.*;

public class sub_string {
    public static int helper(String s) {
        String str = new String();
        Set<Character> st = new HashSet<>();
        int i = 0, j = 0, n = s.length(), res = 0;
        while (i < n && j < n) {
            if(!st.contains(s.charAt(j))){
                st.add(s.charAt(j++));
                res=Math.max(res,j-i);

            }
            else{
                st.remove(s.charAt(i++));
            }


        }
        return res;

    }

    public static void main(String[] args) {
        String str=new String();
        Scanner sc = new Scanner(System.in);
        str=sc.next();
        int ans=helper(str);
        System.out.println("length is"+ans);

    }
}


