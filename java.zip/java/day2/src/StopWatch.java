//Simulate the Stopwatch Program
//a. Desc -> Write a Stopwatch Program for measuring the time that elapses between
//the start and end clicks
//b. I/P -> Start the Stopwatch and End the Stopwatch
//c. Logic -> Measure the elapsed time between start and end
//d. O/P -> Print the elapsed time
import java.util.*;
public class StopWatch {
    public static void main(String[] args) {
        long elapsed=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number to start");
         sc.nextLine();
         long startwatch=System.currentTimeMillis();
        System.out.println(startwatch);

        System.out.println("Enter another number to stoptimmer");
        sc.nextLine();
        long endwatch = System.currentTimeMillis();
        System.out.println(endwatch);

        elapsed= (startwatch-endwatch) ;
        System.out.println(elapsed+"is the elapsed time");



    }
}
