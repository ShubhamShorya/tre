//ax of Three Numbers:
//○ Write a program to find the maximum of three numbers entered by the user
import java.util.Scanner;
public class r_one {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1, num2, num3;
        System.out.println("Please enter 3 numbers");
         num1 = sc.nextInt();
         num2= sc.nextInt();
         num3= sc.nextInt();
        if (num1>=0 && num2>=0 && num3>=0 ) {
            int result=num1>num2 && num1>num3? num1 : num2>num3 && num2>num1 ? num2 : num3;
            System.out.println("Greatesst of three of the number is" + result);

        } else {
            System.out.println("Please enter positive numbers");
        }
    }
}
