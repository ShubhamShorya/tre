//Addition and Subtraction:
//○ Write a program that reads two integers from the user and prints their sum and
//difference.
import java.util.Scanner;
public class a_one {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter the first num");
        int num1=sc.nextInt();
        System.out.println("Please enter the second num");
        int num2=sc.nextInt();
        System.out.println("Sum is : "+ (num1 + num2) );
        System.out.println("Difference is :" + (num1- num2));
    }
}
