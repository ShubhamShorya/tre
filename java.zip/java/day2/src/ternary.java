//○ Write a program to find the minimum of two numbers using the ternary operator.
import java.util.Scanner;

public class ternary {
    public static void main(String[] args) {
     int a=5;
     int b=18;
     int result=a>b?a:b;
        System.out.println((result));



    }
}
