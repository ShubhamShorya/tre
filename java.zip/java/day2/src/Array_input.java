//Array Initialization and Display: Any 2
//○ Write a program to initialize an array with values entered by the user and then
//display the array elements.
import java.util.*;

public class Array_input {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("please enter the size");
        int size= sc.nextInt();
        int[] arr=new int[size];
        System.out.println("Enter the numbers");

        for(int i=0;i<size;i++){

            arr[i]=sc.nextInt();
        }
        for(int i=0;i<size;i++){
            System.out.print(arr[i] + " ");

        }

    }
}
