// Coupon Numbers
//a. Desc -> Given N distinct Coupon Numbers, how many random numbers do you
//need to generate a distinct coupon number? This program simulates this random
//process.
//b. I/P -> N Distinct Coupon Number
//c. Logic -> repeatedly choose a random number and check whether it's a new one.
//d. O/P -> total random number needed to have all distinct numbers.
//e. Functions => Write Class Static Functions to generate random numbers and to
//process distinct coupons
import java.util.Scanner;
import java.util.Random;
import java.util.HashSet;
public class coupon {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size : ");
        int n=sc.nextInt();
        HashSet<Integer> h=new HashSet<>();
        Random r =new Random();
        int count=0,ans = 0


                ;
        while(count!=n){
            int num=r.nextInt() & Integer.MAX_VALUE;
            if(!h.contains(num));
            {
               // System.out.println(num + " ");
                h.add(num);
                count++;
            }
            ans++;
        }
        System.out.println("total number of attempts are :" + ans);
    }

}
