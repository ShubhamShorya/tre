//Bitwise AND, OR, XOR:
//○ Write a program to demonstrate the use of bitwise AND, OR, and XOR operators
//on two integers.
import java.util.Scanner;
public class bitwise_java {
    public static void main(String[] args)
    {
        int a = 8;
        int b = 9;
        System.out.println("a&b = " + (a & b));
        System.out.println("a|b = " + (a | b));
        System.out.println("a^b = " + (a ^ b));

    }
}
