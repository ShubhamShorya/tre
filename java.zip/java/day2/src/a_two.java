//Multiplication Table:
//○ Create a program that prints the multiplication table for a given number.
import java.util.Scanner;

public class a_two {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter the number : ");
        int n=sc.nextInt();
        for(int i=1; i<=10;i++){
            int result=i*n;
            System.out.println(n+ " * "+ i + "= " +result);
        }
    }
}
