//Compound Assignment:
//○ Write a program that demonstrates the use of all compound assignment
//operators (+=, -=, *=, /=, %=).
import java.util.Scanner;
public class assig_one {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int sum=0; int diff=0;
        int mul=10;
        int div=10;
        int modul=2;
        System.out.println("Please enter the two number");
      int num1 = sc.nextInt();
        int num2= sc.nextInt();
            sum+=num1+num2;
        System.out.println("sum"+sum);
            diff-=num2;
        System.out.println("difference"+diff);
            mul*=num1;
        System.out.println("mul "+mul);
            div/=num1 ;
        System.out.println("div " + div);
            modul%=num1;
        System.out.println("modul " + modul);




    }
}
