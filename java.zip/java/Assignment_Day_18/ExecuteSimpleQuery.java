package Assignment_Day_18;

import java.sql.*;

public class ExecuteSimpleQuery {
    private static final String url = "jdbc:postgresql://localhost:5432/company_db";
    private static final String user="postgres";
    private static final String pword ="Digit123";

    public static void main(String[] args) {
        Connection con = null;
        Statement stm = null;
        ResultSet rs = null;

        try{
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url,user,pword);
            stm = con.createStatement();
            String query = "Select * from emp";
            rs = stm.executeQuery(query);
            while(rs.next())
            {
                System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
            }
        }catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        finally {
            try {
                rs.close();
                stm.close();
                con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }
}
