package Assignment_Day_18;

import java.sql.*;
import java.util.Scanner;

public class InsertPreparedStatement {

    private static final String url = "jdbc:postgresql://localhost:5432/inventory_db";
    private static final String user = "postgres";
    private static final String pword = "Digit123";

    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement pst=null;

        try{
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url,user,pword);
            String query = "INSERT INTO product (product_id, name, price, quantity) VALUES (?,?, ?, ?)";
             pst = con.prepareStatement(query);
            Scanner sc = new Scanner(System.in);
            while(true)
            {
                System.out.println("Enter product code :");
                int id = sc.nextInt();
                System.out.println("Enter product name:");
                String product = sc.next();
                System.out.println("Enter price:");
                Double price = sc.nextDouble();
                System.out.println("Enter Quantity:");
                Integer qty = sc.nextInt();
                pst.setInt(1,id);
                pst.setString(2,product);
                pst.setDouble(3,price);
                pst.setInt(4,qty);
                pst.executeUpdate();
                System.out.println("Do you want insert more records: ");
                String option = sc.next();
                if(option.equalsIgnoreCase("no"))
                {
                    break;
                }
            }

        }catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        finally {
            try {
                if(pst!=null)
                    pst.close();
                if(con!=null)
                    con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }
}
