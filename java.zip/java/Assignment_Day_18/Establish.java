package Assignment_Day_18;
import java.sql.*;
public class Establish {

    private static final String url = "jdbc:postgresql://localhost:5432/test_db";
    private static final String user="postgres";
    private static final String pword ="Digit123";

    public static void main(String[] args) {
        Connection con = null;
        Statement stm = null;
        ResultSet rs = null;

        try{
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url,user,pword);
           if(con!=null)
           {
               System.out.println("Connection is established");
           }
           else {
               System.out.println("Connection is not established");
           }
        }catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        finally {
            try {
                con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }
}
