package Assignment_Day_18;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Transaction {

    private static final String url = "jdbc:postgresql://localhost:5432/bank_db";
    private static final String user="postgres";
    private static final String pword ="Digit123";

    public static void main(String[] args) {

        Connection con = null;
        PreparedStatement pst1 = null;
        PreparedStatement pst2 = null;

        Scanner scn = new Scanner(System.in);
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url,user,pword);
            con.setAutoCommit(false);

            String deduct = "Update account set balance = balance - ? where account_number = ?";
            String add = "Update account set balance = balance + ? where account_number = ?";

            System.out.println("Enter your account number:");
            int yourAccNo = scn.nextInt();
            System.out.println("Enter account number whom to send :");
            int recieverAccNO = scn.nextInt();
            System.out.println("Enter amount you want to transfer:");
            double amt = scn.nextDouble();

            pst1 = con.prepareStatement(deduct);
            pst2=con.prepareStatement(add);

            pst1.setDouble(1,amt);
            pst1.setInt(2,yourAccNo);
            pst1.executeUpdate();

            pst2.setDouble(1,amt);
            pst2.setInt(2,recieverAccNO);
            pst2.executeUpdate();

            System.out.println("Do you want to transfer the money [YES/NO]:");
            String option = scn.next();
            if(option.equalsIgnoreCase("yes"))
            {
                con.commit();
                System.out.println("Transaction Successful");
            }
            else {
                con.rollback();
                System.out.println("Transaction Unsuccessful");
            }

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            if(con==null)
            {
                try {
                    con.rollback();
                    System.out.println("Transaction Unsuccessful");
                } catch (SQLException RollBackex) {
                    RollBackex.printStackTrace();
                }
            }
            e.printStackTrace();
        }
        finally {
            try
            {
                 if(pst1!=null)
                     pst1.close();
                if(pst2!=null)
                    pst2.close();
                if(con!=null)
                    con.close();
            }catch (SQLException e)
            {
                e.printStackTrace();
            }
        }

    }
}
