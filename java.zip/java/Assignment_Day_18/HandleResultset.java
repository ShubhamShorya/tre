package Assignment_Day_18;

import java.sql.*;
import java.util.Scanner;

public class HandleResultset {

    private static final String url = "jdbc:postgresql://localhost:5432/school_db";
    private static final String user="postgres";
    private static final String pword ="Digit123";

    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement stm = null;
        PreparedStatement stm2 = null;
        ResultSet rs = null;
        Scanner scanner = new Scanner(System.in);

        try{
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url,user,pword);
            String query = "Select * from student";
            stm = con.prepareStatement(query);
            rs = stm.executeQuery();
            while(rs.next())
            {
                System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
            }
            System.out.println("Enter roll no :");
            int RollNo = scanner.nextInt();
            System.out.println("Enter the grade :");
            Character Grade = scanner.next().charAt(0);
            String query1 = "Update student set grade = ? where roll_no = ?";
            stm2 = con.prepareStatement(query1);
            stm2.setString(1, Character.toString(Grade));
            stm2.setInt(2,RollNo);
            stm2.executeUpdate();

        }catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        finally {
            try {
                rs.close();
                stm.close();
                stm2.close();
                con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }
}
