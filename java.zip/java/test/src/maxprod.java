import java.util.Arrays;

public class maxprod {
    public static void findMaximumProduct(int[] arr) {
        int n = arr.length;
        if (n < 2) {
            System.out.println("Array must have at least two elements");
            return;
        }
        Arrays.sort(arr);


        int product1 = arr[0] * arr[1];
        int product2 = arr[n - 1] * arr[n - 2];

        if (product1 > product2) {
            System.out.println("Pair is (" + arr[0] + ", " + arr[1] + ")");
        } else {
            System.out.println("Pair is (" + arr[n - 1] + ", " + arr[n - 2] + ")");
        }
    }

    public static void main(String[] args) {
        int[] nums = {2, 3, 5, 7, -7, 5, 8, -5};
        findMaximumProduct(nums);
    }
}
