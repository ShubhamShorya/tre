package Geometry_lib;

// Shape.java
interface Shape {
    public abstract double calculateArea();
    public abstract double calculatePerimeter();
}

