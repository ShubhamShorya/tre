package TaskManagement;

class User {
    private String name;
    private Task assignedTask;

    public User(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void assignTask(Task task) {
        this.assignedTask = task;
    }
}

