package TaskManagement;

class Task {
    private String description;
    private boolean isDone;
    private User assignedUser;

    public Task(String description) {
        this.description = description;
        this.isDone = false;
    }
    public boolean getisDone()
    {
        return isDone;
    }

    public String getDescription() {
        return description;
    }

    public void assignTaskToUser(User user) {
        this.assignedUser = user;
        user.assignTask(this);
    }

    public void markAsDone() {
        this.isDone = true;
    }
}
