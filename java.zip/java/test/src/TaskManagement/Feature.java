package TaskManagement;

class Feature extends Task {
    private String priority;

    public Feature(String description, String priority) {
        super(description);
        this.priority = priority;
    }

    public String getPriority() {
        return priority;
    }
}
