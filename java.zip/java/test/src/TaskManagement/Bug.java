package TaskManagement;

class Bug extends Task {
    private String severity;

    public Bug(String description, String severity) {
        super(description);
        this.severity = severity;
    }

    public String getSeverity() {
        return severity;
    }
}
