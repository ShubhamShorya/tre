package TaskManagement;

import java.util.*;
class Project {
    private List<Task> tasks;

    public Project() {
        tasks = new ArrayList<>();
    }

    public void addTask(Task task) {
        tasks.add(task);
    }
}