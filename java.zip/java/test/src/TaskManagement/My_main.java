package TaskManagement;


public class My_main {
    public static void main(String[] args) {
        User user1 = new User("Alice");
        User user2 = new User("Bob");

        Bug bugTask = new Bug("Fix critical bug", "High");
        Feature featureTask = new Feature("Implement new feature", "Medium");

        bugTask.assignTaskToUser(user1);
        featureTask.assignTaskToUser(user2);

        bugTask.markAsDone();
        featureTask.markAsDone();

        Project project = new Project();
        project.addTask(bugTask);
        project.addTask(featureTask);



        System.out.println(user1.getName() + " has the task: " + bugTask.getDescription() +
                " (Severity: " + bugTask.getSeverity() + ", Done: " + bugTask.getisDone()+ ")");
        System.out.println(user2.getName() + " has the task: " + featureTask.getDescription() +
                " (Priority: " + featureTask.getPriority() + ", Done: " + featureTask.getisDone() + ")");
    }
}
