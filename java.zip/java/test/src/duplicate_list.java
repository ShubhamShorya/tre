import java.util.*;

public class duplicate_list {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 2, 2, 3, 4, 4);

        // Create a LinkedHashSet to maintain insertion order
        Set<Integer> set = new LinkedHashSet<>(list);

        // Convert the set back to a list
        List<Integer> uniqueList = new ArrayList<>(set);

        System.out.println("List with duplicates removed: " + uniqueList);
    }
}
