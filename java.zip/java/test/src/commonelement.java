import java.util.*;
import java.util.stream.Collectors;

public class commonelement {
    public static void main(String[] args) {
        List<List<Integer>> lists = new ArrayList<>();
        lists.add(Arrays.asList(1, 3, 5));
        lists.add(Arrays.asList(1, 6, 7, 9, 3));
        lists.add(Arrays.asList(1, 3, 10, 11));


        Set<Integer> commonElements = new HashSet<>(lists.get(0));


            for (int i = 1; i < lists.size(); i++) {
                List<Integer> numbers = lists.get(i);
                Set<Integer> tempSet = new HashSet<>(numbers);
                commonElements.retainAll(tempSet);
            }

        List<Integer> result = new ArrayList<>(commonElements);

        System.out.println("Common elements: " + result);
    }
}
