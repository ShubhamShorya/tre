package Examples;

public class human {
    String name;
    int age;
    int salary;
    boolean marriage;
   static long population;

    public human(String name, int age, int salary, boolean marriage) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.marriage = marriage;
        human.population+=1;
    }
}
