package Examples;

public class demo {
    public static void main(String[] args) {
        human Shubham =new human("Shubham",22, 100000,false);
        human Kunal =new human ("Kunak Kushwaha",23,15000,true);
        human Ashish =new human ("Ashish",25,15000,false);
        System.out.println(human.population);


    }


}
