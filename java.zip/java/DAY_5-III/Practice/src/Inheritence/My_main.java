package Inheritence;

public class My_main {
    public static void main(String[] args) {
//        Box box1=new Box(1.6,4.6,9.9);
//        Box box2 = new Box(box1);
//        System.out.println(box2.l+ " " +box2.w+" "+box2.h);
//        BoxWeight box3 = new BoxWeight();
//        BoxWeight box4 = new BoxWeight(2,3,4,6);
        //System.out.println(box3.l+ " " +box3.w+" "+box3.h+" " +box3.weight);
//         Box box5 =new BoxWeight(2,3,4,5);
//        System.out.println(box5.w);
        BoxPrice box=new BoxPrice();

    }
}
