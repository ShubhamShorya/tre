import java.util.function.BiFunction;

public class Bif8{
    public static void main(String[] args) {
        // Two example input strings
        String str1 = "Hello";
        String str2 = "World";

        // BiFunction to concatenate two strings with a space in between
        BiFunction<String, String, String> concatenateWithSpace = (s1, s2) -> s1 + " " + s2;

        // Using the BiFunction to concatenate the strings
        String result = concatenateWithSpace.apply(str1, str2);

        // Printing the result
        System.out.println(result);
    }
}