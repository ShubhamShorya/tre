@FunctionalInterface
interface SquareCalculator {
    // Abstract method to calculate the square of a number
    int calculateSquare(int x);

    // Default method to print a message along with the result
    default void printSquare(int x) {
        int result = calculateSquare(x);
        System.out.println("The square of " + x + " is: " + result);
    }
}

public class CustomFunction9{
    public static void main(String[] args) {
        // Implementing the SquareCalculator interface using a lambda expression
        SquareCalculator calculator = x -> x * x;

        // Example input
        int number = 5;

        // Using the default method to print the square of the number
        calculator.printSquare(number);
    }
}