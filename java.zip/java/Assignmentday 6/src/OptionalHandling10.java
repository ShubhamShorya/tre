import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class OptionalHandling10{
    public static void main(String[] args) {
        // List of integers
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        // Finding the maximum value in the list and returning it as Optional<Integer>
        Optional<Integer> max = numbers.stream().max(Integer::compare);

        // Handling the case when the list is empty
        if (max.isPresent()) {
            System.out.println("The maximum value is: " + max.get());
        } else {
            System.out.println("The list is empty, no maximum value.");
        }

        // Example with an empty list
        List<Integer> emptyList = Collections.emptyList();
        Optional<Integer> maxEmpty = emptyList.stream().max(Integer::compare);

        // Handling the case when the list is empty
        if (maxEmpty.isPresent()) {
            System.out.println("The maximum value is: " + maxEmpty.get());
        } else {
            System.out.println("The list is empty, no maximum value.");
        }
    }
}