import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Filtering_list2{
    public static void main(String[] args) {

        List<String> strings = Arrays.asList("Apple", "Banana", "Avocado", "Cherry", "Apricot", "Blueberry");


        List<String> filteredStrings = strings.stream()
                .filter(s -> s.startsWith("A"))
                .collect(Collectors.toList());


        filteredStrings.forEach(System.out::println);
    }
}