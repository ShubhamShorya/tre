import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Insurance_problemstatement
{

    public static void main(String[] args) {
        // Sample list of policies
        List<Policy> policies = Arrays.asList(
                new Policy("P001", "John Smith", 1500.0),
                new Policy("P002", "Jane Doe", 1800.0),
                new Policy("P003", "John Doe", 1100.0),
                new Policy("P004", "Alice Johnson", 2000.0),
                new Policy("P005", "Smith Johnson", 2500.0)
        );

        // Extract Unique Holder Names
        Set<String> uniqueHolderNames = policies.stream()
                .map(Policy::getHolderName)
                .collect(Collectors.toSet());
        System.out.println("Unique Holder Names: " + uniqueHolderNames);

        // Find Policies by Holder Name Substring
        String substring = "Smith";
        List<Policy> policiesWithSubstring = policies.stream()
                .filter(policy -> policy.getHolderName().contains(substring))
                .collect(Collectors.toList());
        System.out.println("Policies with Substring \"" + substring + "\": " + policiesWithSubstring);

        // Create a Map of Policy Numbers to Premium Amounts
        Map<String, Double> policyNumberToPremium = policies.stream()
                .collect(Collectors.toMap(
                        Policy::getPolicyNumber,
                        Policy::getPremiumAmount
                ));
        System.out.println("Policy Numbers to Premium Amounts: " + policyNumberToPremium);

        // Finding the Most Frequent Words in a Text Corpus
        String text = "This is a sample text corpus. This text is for testing the most frequent words in the text corpus. The text contains repeated words, repeated words.";
        Map<String, Long> wordCounts = Arrays.stream(text.toLowerCase().split("\\W+"))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        int topN = 3;
        List<Map.Entry<String, Long>> topNWords = wordCounts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(topN)
                .collect(Collectors.toList());
        System.out.println("Top " + topN + " Words: " + topNWords);

        // Finding the Second Most Repeated Word
        String secondMostRepeatedWord = wordCounts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .skip(1)
                .findFirst()
                .map(Map.Entry::getKey)
                .orElse(null);
        System.out.println("Second Most Repeated Word: " + secondMostRepeatedWord);
    }
}

class Policy {
    private String policyNumber;
    private String holderName;
    private double premiumAmount;

    public Policy(String policyNumber, String holderName, double premiumAmount) {
        this.policyNumber = policyNumber;
        this.holderName = holderName;
        this.premiumAmount = premiumAmount;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getHolderName() {
        return holderName;
    }

    public double getPremiumAmount() {
        return premiumAmount;
    }

    @Override
    public String toString() {
        return "Policy Number: " + policyNumber + ", Holder Name: " + holderName + ", Premium Amount: " + premiumAmount;
    }
}
