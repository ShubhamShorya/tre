package com.Assignment.Day21Api.Controller;

import com.Assignment.Day21Api.Model.Product;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
public class ProductController {

    private List<Product> products = new ArrayList<>();

    public ProductController() {
        // Adding some sample products
        products.add(new Product(1L, "Laptop", "electronics", 999.99));
        products.add(new Product(2L, "Smartphone", "electronics", 699.99));
        products.add(new Product(3L, "Sofa", "furniture", 499.99));
        products.add(new Product(4L, "Table", "furniture", 199.99));
    }

    @GetMapping("/products/{category}/{id}")
    public Product getProductByCategoryAndId(@PathVariable String category, @PathVariable Long id) {
        Optional<Product> product = products.stream()
                .filter(p -> p.getCategory().equalsIgnoreCase(category) && p.getId().equals(id))
                .findFirst();
        return product.orElse(null); // Return null if product not found
    }
}

