package com.Assignment.Day21Api.Controller;

import com.Assignment.Day21Api.Model.User;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class UserController {

    private List<User> users = new ArrayList<>();

    public UserController() {
        // Adding some sample users
        users.add(new User(1L, "Alice", 25, "NewYork"));
        users.add(new User(2L, "Bob", 30, "LosAngeles"));
        users.add(new User(3L, "Charlie", 25, "NewYork"));
        users.add(new User(4L, "David", 35, "Chicago"));
    }

    @GetMapping("/users/filter")
    public List<User> filterUsers(
            @RequestParam(required = false) Integer age,
            @RequestParam(required = false) String city) {
        return users.stream()
                .filter(user -> (age == null || user.getAge() == age) &&
                        (city == null || user.getCity().equalsIgnoreCase(city)))
                .collect(Collectors.toList());
    }

    @GetMapping("/users/{id}")
    public User getUserById(@PathVariable Long id) {
        Optional<User> user = users.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst();
        return user.orElse(null); // Return null if user not found
    }
}