package com.Assignment.Day21Api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day21ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day21ApiApplication.class, args);
	}

}
